import { useMemo } from 'react';
import { StyleSheet, View } from 'react-native';
import { espacos, raios, sombra } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

export default function Cartao({ children, style }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  return <View style={[styles.cartao, style]}>{children}</View>;
}

const criarEstilos = (cores) => StyleSheet.create({
  cartao: {
    backgroundColor: cores.superficie,
    borderRadius: raios.lg,
    borderWidth: 1,
    borderColor: cores.borda,
    padding: espacos.md,
    marginBottom: espacos.md,
    ...sombra,
  },
});
