import { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { espacos, fontes, raios, sombra } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

// Número em destaque com legenda (ex.: "12 · Entradas").
export default function CartaoResumo({ valor, legenda, destaque }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  return (
    <View style={styles.cartao} accessible accessibilityLabel={`${legenda}: ${valor}`}>
      <Text style={styles.valor}>{valor}</Text>
      {destaque ? <Text style={styles.destaque}>{destaque}</Text> : null}
      <Text style={styles.legenda}>{legenda}</Text>
    </View>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  cartao: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 92,
    padding: espacos.sm,
    borderRadius: raios.lg,
    borderWidth: 1,
    borderColor: cores.borda,
    backgroundColor: cores.superficie,
    ...sombra,
  },
  valor: { fontSize: 26, fontWeight: '800', color: cores.primariaEscura },
  destaque: { fontSize: 18 },
  legenda: { fontSize: fontes.pequena, color: cores.textoSuave, marginTop: 2, textAlign: 'center' },
});
