import { StyleSheet, Text, View } from 'react-native';
import { espacos, fontes, raios } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

// tipo: 'erro' | 'sucesso' | 'info'. Não mostra nada se o texto estiver vazio.
export default function MensagemFeedback({ texto, tipo = 'erro', style }) {
  const { cores } = useTema();
  if (!texto) return null;
  const aparencia = aparenciaDe(cores)[tipo];
  return (
    <View
      style={[styles.caixa, { backgroundColor: aparencia.fundo }, style]}
      accessibilityRole="alert"
      accessibilityLiveRegion="polite"
    >
      <Text style={[styles.texto, { color: aparencia.texto }]}>{texto}</Text>
    </View>
  );
}

const aparenciaDe = (cores) => ({
  erro: { fundo: cores.erroFundo, texto: cores.erro },
  sucesso: { fundo: cores.sucessoFundo, texto: cores.sucesso },
  info: { fundo: cores.infoFundo, texto: cores.infoTexto },
});

// As cores vêm do tema (acima); aqui ficam só medidas e fontes.
const styles = StyleSheet.create({
  caixa: { borderRadius: raios.md, padding: espacos.md, marginBottom: espacos.md },
  texto: { fontSize: fontes.pequena + 1, lineHeight: 20, fontWeight: '600' },
});
