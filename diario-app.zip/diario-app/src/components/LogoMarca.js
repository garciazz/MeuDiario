import { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { espacos, fontes } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

// Identidade do app nas telas de entrada (login e cadastro).
export default function LogoMarca({ compacta = false }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  return (
    <View style={[styles.caixa, compacta && styles.compacta]}>
      <View style={[styles.circulo, compacta && styles.circuloCompacto]}>
        <Text style={[styles.emoji, compacta && styles.emojiCompacto]}>🌼</Text>
      </View>
      <Text style={styles.nome}>Meu Diário</Text>
      <Text style={styles.frase}>Um cantinho seguro para as suas emoções</Text>
    </View>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  caixa: { alignItems: 'center', marginTop: espacos.lg, marginBottom: espacos.lg },
  compacta: { marginTop: espacos.sm, marginBottom: espacos.md },
  circulo: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: cores.destaque,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: espacos.md,
  },
  circuloCompacto: { width: 64, height: 64, borderRadius: 32, marginBottom: espacos.sm },
  emoji: { fontSize: 44 },
  emojiCompacto: { fontSize: 32 },
  nome: { fontSize: fontes.titulo, fontWeight: '800', color: cores.texto },
  frase: { fontSize: fontes.pequena + 1, color: cores.textoSuave, marginTop: espacos.xs },
});
