import { useMemo } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { espacos, fontes } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

// tela: true ocupa a tela toda (abertura do app); false é um indicador dentro do conteúdo.
export default function Carregando({ mensagem, tela = false }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  return (
    <View style={[styles.caixa, tela && styles.tela]} accessibilityLiveRegion="polite">
      <ActivityIndicator size="large" color={cores.primaria} />
      {mensagem ? <Text style={styles.mensagem}>{mensagem}</Text> : null}
    </View>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  caixa: { alignItems: 'center', justifyContent: 'center', padding: espacos.lg },
  tela: { flex: 1, backgroundColor: cores.fundo },
  mensagem: { marginTop: espacos.md, color: cores.textoSuave, fontSize: fontes.corpo },
});
