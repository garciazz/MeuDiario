import { StyleSheet, View } from 'react-native';
import ChipSelecionavel from './ChipSelecionavel';
import { PERIODOS } from '../models/relatorioModel';
import { espacos } from '../theme/tema';

export default function SeletorPeriodo({ periodo, onMudar }) {
  return (
    <View style={styles.linha}>
      {PERIODOS.map((item) => (
        <ChipSelecionavel
          key={item.dias}
          titulo={item.rotulo}
          selecionado={item.dias === periodo}
          onPress={() => onMudar(item.dias)}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  linha: { flexDirection: 'row', gap: espacos.sm, marginBottom: espacos.md },
});
