import { useMemo } from 'react';
import { Pressable, StyleSheet, Text } from 'react-native';
import { espacos, fontes, raios } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

// Botão em formato de pílula que liga/desliga (áreas de interesse, período do relatório).
export default function ChipSelecionavel({ titulo, selecionado, onPress, desabilitado = false }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  return (
    <Pressable
      onPress={onPress}
      disabled={desabilitado}
      accessibilityRole="button"
      accessibilityState={{ selected: selecionado, disabled: desabilitado }}
      style={[styles.chip, selecionado && styles.chipSelecionado, desabilitado && styles.chipDesabilitado]}
    >
      <Text style={[styles.texto, selecionado && styles.textoSelecionado]}>{titulo}</Text>
    </Pressable>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  chip: {
    paddingVertical: espacos.sm,
    paddingHorizontal: espacos.md,
    borderRadius: raios.pilula,
    borderWidth: 1.5,
    borderColor: cores.borda,
    backgroundColor: cores.fundo,
  },
  chipSelecionado: { backgroundColor: cores.secundariaClara, borderColor: cores.secundaria },
  chipDesabilitado: { opacity: 0.5 },
  texto: { fontSize: fontes.pequena + 1, color: cores.textoSuave, fontWeight: '600' },
  textoSelecionado: { color: cores.sucesso, fontWeight: '700' },
});
