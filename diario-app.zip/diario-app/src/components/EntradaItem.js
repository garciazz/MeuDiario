import { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Cartao from './Cartao';
import { corDoHumor, espacos, fontes } from '../theme/tema';
import { useTema } from '../theme/TemaContext';
import { rotuloRelativo } from '../utils/datas';

// As respostas vêm como "O que me fez bem: ...": o rótulo aparece em negrito.
function Linha({ texto, styles }) {
  const posicao = texto.indexOf(': ');
  const temRotulo = texto.startsWith('O que ') && posicao > 0;
  if (!temRotulo) return <Text style={styles.texto}>{texto}</Text>;
  return (
    <Text style={styles.texto}>
      <Text style={styles.rotulo}>{texto.slice(0, posicao + 2)}</Text>
      {texto.slice(posicao + 2)}
    </Text>
  );
}

export default function EntradaItem({ entrada }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  const { humor, data_entrada: data, texto } = entrada;
  return (
    <Cartao style={styles.cartao}>
      <View style={[styles.faixa, { backgroundColor: corDoHumor(humor.valor) }]} />
      <View style={styles.conteudo}>
        <View style={styles.topo}>
          <Text style={styles.emoji}>{humor.icone}</Text>
          <View style={styles.titulos}>
            <Text style={styles.humor}>{humor.nome}</Text>
            <Text style={styles.data}>{rotuloRelativo(data)}</Text>
          </View>
        </View>
        {texto.split('\n').map((linha, indice) => (
          <Linha key={indice} texto={linha} styles={styles} />
        ))}
      </View>
    </Cartao>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  cartao: { flexDirection: 'row', padding: 0, overflow: 'hidden' },
  faixa: { width: 6 },
  conteudo: { flex: 1, padding: espacos.md },
  topo: { flexDirection: 'row', alignItems: 'center', marginBottom: espacos.sm },
  emoji: { fontSize: 30, marginRight: espacos.sm },
  titulos: { flex: 1 },
  humor: { fontSize: fontes.corpo, fontWeight: '800', color: cores.texto },
  data: { fontSize: fontes.pequena, color: cores.textoSuave },
  texto: { fontSize: fontes.pequena + 1, lineHeight: 20, color: cores.texto, marginTop: 2 },
  rotulo: { fontWeight: '700', color: cores.primariaEscura },
});
