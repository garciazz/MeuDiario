import { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Botao from './Botao';
import { espacos, fontes, raios } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

// Botão que abre a lista de temas de cores. Escolher um tema muda o app na hora e fica salvo no aparelho.
export default function SeletorTema() {
  const { cores, tema, temas, escolherTema } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  const [aberto, setAberto] = useState(false);

  return (
    <View>
      <Text style={styles.atual}>
        Tema atual: <Text style={styles.atualNome}>{tema.nome}</Text>
      </Text>
      <Botao
        titulo={aberto ? 'Fechar temas' : 'Escolher outro tema de cores'}
        variante="secundario"
        onPress={() => setAberto((v) => !v)}
      />

      {aberto ? (
        <View style={styles.lista} accessibilityRole="radiogroup">
          {temas.map((item) => {
            const selecionado = item.id === tema.id;
            return (
              <Pressable
                key={item.id}
                onPress={() => escolherTema(item.id)}
                accessibilityRole="radio"
                accessibilityLabel={`Tema ${item.nome}`}
                accessibilityState={{ selected: selecionado, checked: selecionado }}
                aria-checked={selecionado}
                style={[styles.item, selecionado && styles.itemSelecionado]}
              >
                {/* Amostra das cores do próprio tema (não do tema atual). */}
                <View style={[styles.amostra, { backgroundColor: item.cores.fundo, borderColor: item.cores.borda }]}>
                  <View style={[styles.ponto, { backgroundColor: item.cores.primaria }]} />
                  <View style={[styles.ponto, { backgroundColor: item.cores.secundaria }]} />
                  <View style={[styles.ponto, { backgroundColor: item.cores.destaque }]} />
                </View>
                <View style={styles.textos}>
                  <Text style={styles.nome}>
                    {item.nome}
                    {item.id === 'acolhedor' ? ' (padrão)' : ''}
                  </Text>
                  <Text style={styles.descricao}>{item.descricao}</Text>
                </View>
                {selecionado ? <Text style={styles.marca}>✓</Text> : null}
              </Pressable>
            );
          })}
        </View>
      ) : null}
    </View>
  );
}

const criarEstilos = (cores) =>
  StyleSheet.create({
    atual: { fontSize: fontes.corpo, color: cores.texto, marginBottom: espacos.sm },
    atualNome: { fontWeight: '800' },
    lista: { marginTop: espacos.md, gap: espacos.sm },
    item: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: espacos.md,
      padding: espacos.md,
      borderRadius: raios.md,
      borderWidth: 2,
      borderColor: cores.borda,
      backgroundColor: cores.fundo,
    },
    itemSelecionado: { borderColor: cores.primaria, backgroundColor: cores.primariaClara },
    amostra: {
      flexDirection: 'row',
      gap: 4,
      padding: 8,
      borderRadius: raios.sm,
      borderWidth: 1,
    },
    ponto: { width: 16, height: 16, borderRadius: 8 },
    textos: { flex: 1 },
    nome: { fontSize: fontes.corpo, fontWeight: '800', color: cores.texto },
    descricao: { fontSize: fontes.pequena + 1, color: cores.textoSuave, marginTop: 2 },
    marca: { fontSize: 20, fontWeight: '900', color: cores.primariaEscura },
  });
