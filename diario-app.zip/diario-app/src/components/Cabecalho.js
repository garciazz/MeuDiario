import { useMemo } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { espacos, fontes } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

// Título da tela com subtítulo e uma ação opcional à direita (ex.: Sair).
export default function Cabecalho({ titulo, subtitulo, acao }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  return (
    <View style={styles.linha}>
      <View style={styles.textos}>
        <Text style={styles.titulo} accessibilityRole="header">
          {titulo}
        </Text>
        {subtitulo ? <Text style={styles.subtitulo}>{subtitulo}</Text> : null}
      </View>
      {acao ? (
        <Pressable onPress={acao.onPress} hitSlop={10} accessibilityRole="button">
          <Text style={styles.acao}>{acao.titulo}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  linha: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginBottom: espacos.md,
  },
  textos: { flex: 1, paddingRight: espacos.md },
  titulo: { fontSize: fontes.titulo, fontWeight: '800', color: cores.texto },
  subtitulo: { fontSize: fontes.corpo, color: cores.textoSuave, marginTop: espacos.xs },
  acao: { color: cores.primariaEscura, fontWeight: '700', fontSize: fontes.corpo, paddingTop: 6 },
});
