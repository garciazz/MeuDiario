import { useMemo } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { espacos, fontes } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

const ABAS = [
  { chave: 'diario', icone: '📝', titulo: 'Diário' },
  { chave: 'relatorio', icone: '📊', titulo: 'Relatório' },
  { chave: 'privacidade', icone: '🔒', titulo: 'Privacidade' },
];

// Barra de navegação inferior (Diário | Relatório | Privacidade), com respeito à área segura de baixo.
export default function BarraAbas({ abaAtiva, onMudar }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  return (
    <SafeAreaView edges={['bottom', 'left', 'right']} style={styles.barra}>
      <View style={styles.linha}>
        {ABAS.map((aba) => {
          const ativa = aba.chave === abaAtiva;
          return (
            <Pressable
              key={aba.chave}
              onPress={() => onMudar(aba.chave)}
              accessibilityRole="tab"
              accessibilityState={{ selected: ativa }}
              accessibilityLabel={aba.titulo}
              style={styles.aba}
            >
              <View style={[styles.pilula, ativa && styles.pilulaAtiva]}>
                <Text style={styles.icone}>{aba.icone}</Text>
                <Text style={[styles.titulo, ativa && styles.tituloAtivo]}>{aba.titulo}</Text>
              </View>
            </Pressable>
          );
        })}
      </View>
    </SafeAreaView>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  barra: { backgroundColor: cores.superficie, borderTopWidth: 1, borderTopColor: cores.borda },
  linha: { flexDirection: 'row', paddingVertical: espacos.sm },
  aba: { flex: 1, alignItems: 'center' },
  pilula: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingVertical: espacos.sm,
    paddingHorizontal: espacos.md,
    borderRadius: 999,
  },
  pilulaAtiva: { backgroundColor: cores.primariaClara },
  icone: { fontSize: 18 },
  titulo: { fontSize: fontes.pequena + 1, color: cores.textoSuave, fontWeight: '600' },
  tituloAtivo: { color: cores.primariaEscura, fontWeight: '800' },
});
