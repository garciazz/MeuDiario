import { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import BlocosDeTexto from './BlocosDeTexto';
import Botao from './Botao';
import { espacos, fontes } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

// Aviso de consentimento: título, o que é coletado, para quê, onde ficam os dados e links para o Termo e a Política.
export default function AvisoConsentimento({ aviso, onAbrirDocumento }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  return (
    <View>
      <Text style={styles.titulo} accessibilityRole="header">
        {aviso.titulo}
      </Text>
      <BlocosDeTexto blocos={aviso.blocos} />
      <View style={styles.links}>
        <Botao titulo="Ler o Termo completo" variante="secundario" onPress={() => onAbrirDocumento('termo')} />
        <Botao titulo="Ler a Política de Privacidade" variante="secundario" onPress={() => onAbrirDocumento('politica')} />
      </View>
    </View>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  titulo: { fontSize: fontes.subtitulo, fontWeight: '800', color: cores.texto, marginBottom: espacos.sm },
  links: { gap: espacos.sm, marginTop: espacos.sm, marginBottom: espacos.sm },
});
