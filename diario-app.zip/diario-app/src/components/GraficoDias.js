import { useRef, useMemo } from 'react';
import { FlatList, StyleSheet, Text, View } from 'react-native';
import { corDoHumor, espacos, fontes, raios } from '../theme/tema';
import { useTema } from '../theme/TemaContext';
import { rotuloCurto } from '../utils/datas';

const ALTURA_BARRAS = 110;

// Gráfico de colunas: humor médio de cada dia do período (1 a 5). Rola na horizontal
// e começa pelos dias mais recentes. Dias sem registro aparecem como um ponto cinza.
export default function GraficoDias({ serie }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  const listaRef = useRef(null);
  const larguraColuna = serie.length <= 7 ? 46 : 34;

  return (
    <FlatList
      ref={listaRef}
      data={serie}
      horizontal
      keyExtractor={(dia) => dia.data}
      showsHorizontalScrollIndicator={false}
      onContentSizeChange={() => listaRef.current?.scrollToEnd({ animated: false })}
      renderItem={({ item }) => (
        <View
          style={[styles.coluna, { width: larguraColuna }]}
          accessible
          accessibilityLabel={
            item.humor
              ? `${rotuloCurto(item.data)}: ${item.humor.nome}`
              : `${rotuloCurto(item.data)}: sem registro`
          }
        >
          <Text style={styles.emoji}>{item.humor ? item.humor.icone : ' '}</Text>
          <View style={styles.area}>
            {item.media !== null ? (
              <View
                style={[
                  styles.barra,
                  {
                    height: Math.max((item.media / 5) * ALTURA_BARRAS, 10),
                    backgroundColor: corDoHumor(item.media),
                  },
                ]}
              />
            ) : (
              <View style={styles.ponto} />
            )}
          </View>
          <Text style={styles.data}>{rotuloCurto(item.data)}</Text>
        </View>
      )}
    />
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  coluna: { alignItems: 'center' },
  emoji: { fontSize: 16, height: 22 },
  area: { height: ALTURA_BARRAS, justifyContent: 'flex-end', alignItems: 'center' },
  barra: { width: 16, borderRadius: raios.sm },
  ponto: { width: 6, height: 6, borderRadius: 3, backgroundColor: cores.borda, marginBottom: 2 },
  data: { marginTop: espacos.xs, fontSize: fontes.minima - 1, color: cores.textoSuave },
});
