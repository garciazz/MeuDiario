import { FlatList, View } from 'react-native';
import { espacos, larguraMaxima } from '../theme/tema';

// Estilo do conteúdo rolável: centralizado e com largura máxima (tablets e navegador).
// Também usado pela lista do Diário, para manter tudo alinhado.
export const estiloConteudoCentral = {
  width: '100%',
  maxWidth: larguraMaxima,
  alignSelf: 'center',
  padding: espacos.md,
  paddingBottom: espacos.xl,
};

// Área rolável para telas de formulário e relatório. Usa uma FlatList sem itens,
// com o conteúdo no cabeçalho da lista (o mesmo recurso usado nas listas de verdade).
export default function ConteudoRolavel({ children, ...resto }) {
  return (
    <FlatList
      data={[]}
      renderItem={() => null}
      keyboardShouldPersistTaps="handled"
      showsVerticalScrollIndicator={false}
      contentContainerStyle={estiloConteudoCentral}
      ListHeaderComponent={<View>{children}</View>}
      {...resto}
    />
  );
}
