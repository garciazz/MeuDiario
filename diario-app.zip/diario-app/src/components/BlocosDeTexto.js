import { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { espacos, fontes, raios } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

// Desenha os blocos de texto vindos da API: parágrafo, subtítulo, lista e tabela.
// Em celulares a tabela vira uma lista de cartões (uma tabela de 4 colunas não cabe na tela).
export function Bloco({ bloco }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  switch (bloco.tipo) {
    case 'subtitulo':
      return (
        <Text style={styles.subtitulo} accessibilityRole="header">
          {bloco.texto}
        </Text>
      );
    case 'lista':
      return (
        <View style={styles.lista}>
          {bloco.itens.map((item) => (
            <View key={item} style={styles.item}>
              <Text style={styles.marcador}>•</Text>
              <Text style={styles.itemTexto}>{item}</Text>
            </View>
          ))}
        </View>
      );
    case 'tabela':
      return (
        <View style={styles.tabela}>
          {bloco.linhas.map((linha) => (
            <View key={linha[0]} style={styles.linhaTabela}>
              <Text style={styles.tabelaTitulo}>{linha[0]}</Text>
              {linha.slice(1).map((valor, i) => (
                <Text key={bloco.colunas[i + 1]} style={styles.tabelaTexto}>
                  <Text style={styles.tabelaRotulo}>{bloco.colunas[i + 1]}: </Text>
                  {valor}
                </Text>
              ))}
            </View>
          ))}
        </View>
      );
    default:
      return <Text style={styles.paragrafo}>{bloco.texto}</Text>;
  }
}

export default function BlocosDeTexto({ blocos }) {
  return (
    <View>
      {blocos.map((bloco, i) => (
        <Bloco key={i} bloco={bloco} />
      ))}
    </View>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  subtitulo: { fontSize: fontes.corpo + 1, fontWeight: '800', color: cores.texto, marginTop: espacos.md, marginBottom: espacos.xs },
  paragrafo: { fontSize: fontes.corpo, lineHeight: 24, color: cores.texto, marginBottom: espacos.sm },
  lista: { marginBottom: espacos.sm, gap: 6 },
  item: { flexDirection: 'row', gap: espacos.sm, paddingRight: espacos.sm },
  marcador: { fontSize: fontes.corpo, lineHeight: 24, color: cores.primaria, fontWeight: '900' },
  itemTexto: { flex: 1, fontSize: fontes.corpo, lineHeight: 24, color: cores.texto },
  tabela: { gap: espacos.sm, marginBottom: espacos.sm },
  linhaTabela: { backgroundColor: cores.fundo, borderRadius: raios.md, borderWidth: 1, borderColor: cores.borda, padding: espacos.md, gap: 4 },
  tabelaTitulo: { fontSize: fontes.corpo, fontWeight: '800', color: cores.texto },
  tabelaTexto: { fontSize: fontes.corpo - 1, lineHeight: 21, color: cores.texto },
  tabelaRotulo: { fontWeight: '700', color: cores.textoSuave },
});
