import { useMemo } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import Carregando from './Carregando';
import Botao from './Botao';
import MensagemFeedback from './MensagemFeedback';
import { corDoHumor, espacos, fontes, raios } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

// Lista horizontal de emoções vinda da API: aceita novas emoções cadastradas no banco.
export default function SeletorHumor({ humores, selecionadoId, onSelecionar, carregando, erro, onTentarNovamente }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  if (carregando) return <Carregando mensagem="Carregando emoções..." />;
  if (erro) {
    return (
      <View>
        <MensagemFeedback texto={erro} />
        <Botao titulo="Tentar de novo" variante="secundario" onPress={onTentarNovamente} />
      </View>
    );
  }

  return (
    <FlatList
      data={humores}
      horizontal
      extraData={selecionadoId}
      keyExtractor={(humor) => String(humor.id)}
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.lista}
      renderItem={({ item }) => {
        const selecionado = item.id === selecionadoId;
        return (
          <Pressable
            onPress={() => onSelecionar(item.id)}
            accessibilityRole="radio"
            accessibilityLabel={item.nome}
            accessibilityState={{ selected: selecionado }}
            style={[
              styles.item,
              selecionado && { backgroundColor: corDoHumor(item.valor) + '33', borderColor: corDoHumor(item.valor) },
            ]}
          >
            <Text style={styles.emoji}>{item.icone}</Text>
            <Text style={[styles.nome, selecionado && styles.nomeSelecionado]} numberOfLines={2}>
              {item.nome}
            </Text>
          </Pressable>
        );
      }}
    />
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  // Largura pensada para as 5 emoções caberem sem rolar em celulares comuns;
  // se houver mais emoções cadastradas, a lista rola na horizontal.
  lista: { paddingVertical: espacos.xs, gap: 6 },
  item: {
    width: 60,
    minHeight: 84,
    alignItems: 'center',
    paddingVertical: espacos.sm,
    paddingHorizontal: 2,
    borderRadius: raios.md,
    borderWidth: 2,
    borderColor: cores.borda,
    backgroundColor: cores.fundo,
  },
  emoji: { fontSize: 30 },
  nome: { marginTop: 2, fontSize: fontes.minima, lineHeight: 13, color: cores.textoSuave, textAlign: 'center' },
  nomeSelecionado: { color: cores.texto, fontWeight: '700' },
});
