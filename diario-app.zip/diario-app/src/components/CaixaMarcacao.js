import { useMemo } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { espacos, fontes, raios } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

// Caixa de seleção com texto. Sempre começa desmarcada: quem controla o valor é a tela.
export default function CaixaMarcacao({ marcada, onAlternar, texto, erro }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  return (
    <View>
      <Pressable
        onPress={() => onAlternar(!marcada)}
        accessibilityRole="checkbox"
        accessibilityLabel={texto}
        accessibilityState={{ checked: marcada }}
        aria-checked={marcada}
        style={styles.linha}
      >
        <View style={[styles.caixa, marcada && styles.caixaMarcada, erro && styles.caixaErro]}>
          {marcada ? <Text style={styles.marca}>✓</Text> : null}
        </View>
        <Text style={styles.texto}>{texto}</Text>
      </Pressable>
      {erro ? <Text style={styles.erro}>{erro}</Text> : null}
    </View>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  linha: { flexDirection: 'row', alignItems: 'flex-start', gap: espacos.md, paddingVertical: espacos.sm },
  caixa: {
    width: 26,
    height: 26,
    borderRadius: raios.sm - 4,
    borderWidth: 2,
    borderColor: cores.primaria,
    backgroundColor: cores.superficie,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 1,
  },
  caixaMarcada: { backgroundColor: cores.primaria },
  caixaErro: { borderColor: cores.erro },
  marca: { color: cores.textoSobrePrimaria, fontWeight: '900', fontSize: 16, lineHeight: 18 },
  texto: { flex: 1, fontSize: fontes.corpo, lineHeight: 22, color: cores.texto, fontWeight: '600' },
  erro: { color: cores.erro, fontSize: fontes.pequena + 1, marginTop: 2 },
});
