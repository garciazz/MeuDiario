import { useMemo } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text } from 'react-native';
import { espacos, fontes, raios } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

// variante: 'primario' (preenchido), 'secundario' (contorno) ou 'link' (só texto).
export default function Botao({
  titulo,
  onPress,
  variante = 'primario',
  carregando = false,
  desabilitado = false,
  style,
}) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  const inativo = desabilitado || carregando;
  const corDoTexto = variante === 'primario' ? cores.textoSobrePrimaria : cores.primariaEscura;

  return (
    <Pressable
      onPress={onPress}
      disabled={inativo}
      accessibilityRole="button"
      accessibilityLabel={titulo}
      accessibilityState={{ disabled: inativo, busy: carregando }}
      style={({ pressed }) => [
        styles.base,
        styles[variante],
        inativo && variante === 'primario' && styles.primarioInativo,
        pressed && styles.pressionado,
        style,
      ]}
    >
      {carregando ? (
        <ActivityIndicator color={corDoTexto} />
      ) : (
        <Text style={[styles.texto, { color: corDoTexto }]}>{titulo}</Text>
      )}
    </Pressable>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  base: {
    minHeight: 50,
    borderRadius: raios.pilula,
    paddingHorizontal: espacos.lg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  primario: { backgroundColor: cores.primaria },
  secundario: { backgroundColor: 'transparent', borderWidth: 1.5, borderColor: cores.primaria },
  link: { backgroundColor: 'transparent' },
  texto: { fontSize: fontes.corpo, fontWeight: '700' },
  primarioInativo: { backgroundColor: cores.desabilitado },
  pressionado: { opacity: 0.8 },
});
