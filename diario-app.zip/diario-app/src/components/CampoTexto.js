import { useState, useMemo } from 'react';
import { Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { espacos, fontes, raios } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

// Campo de formulário com rótulo, mensagem de erro e (opcionalmente) botão mostrar/ocultar senha.
export default function CampoTexto({ rotulo, erro, senha = false, style, ...resto }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  const [senhaVisivel, setSenhaVisivel] = useState(false);
  const [focado, setFocado] = useState(false);

  return (
    <View style={styles.grupo}>
      {rotulo ? <Text style={styles.rotulo}>{rotulo}</Text> : null}
      <View style={[styles.caixa, focado && styles.focada, !!erro && styles.comErro]}>
        <TextInput
          style={[styles.input, resto.multiline && styles.multilinha, style]}
          placeholderTextColor={cores.textoSuave}
          secureTextEntry={senha && !senhaVisivel}
          onFocus={() => setFocado(true)}
          onBlur={() => setFocado(false)}
          accessibilityLabel={rotulo}
          {...resto}
        />
        {senha ? (
          <Pressable
            onPress={() => setSenhaVisivel((v) => !v)}
            hitSlop={10}
            accessibilityRole="button"
            accessibilityLabel={senhaVisivel ? 'Ocultar senha' : 'Mostrar senha'}
          >
            <Text style={styles.mostrar}>{senhaVisivel ? 'Ocultar' : 'Mostrar'}</Text>
          </Pressable>
        ) : null}
      </View>
      {erro ? <Text style={styles.erro}>{erro}</Text> : null}
    </View>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  grupo: { marginBottom: espacos.md },
  rotulo: {
    fontSize: fontes.pequena,
    fontWeight: '700',
    color: cores.texto,
    marginBottom: espacos.xs,
  },
  caixa: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: cores.fundo,
    borderWidth: 1.5,
    borderColor: cores.borda,
    borderRadius: raios.md,
    paddingHorizontal: espacos.md,
  },
  focada: { borderColor: cores.primaria, backgroundColor: cores.superficie },
  comErro: { borderColor: cores.erro },
  input: {
    flex: 1,
    minHeight: 48,
    fontSize: fontes.corpo,
    color: cores.texto,
    ...Platform.select({ web: { outlineStyle: 'none' } }),
  },
  multilinha: { minHeight: 84, paddingVertical: espacos.sm, textAlignVertical: 'top' },
  mostrar: { color: cores.primariaEscura, fontWeight: '700', fontSize: fontes.pequena },
  erro: { color: cores.erro, fontSize: fontes.pequena, marginTop: espacos.xs },
});
