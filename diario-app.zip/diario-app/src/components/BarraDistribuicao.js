import { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { corDoHumor, espacos, fontes, raios } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

// Uma linha do gráfico de distribuição: emoji, nome, barra proporcional e quantidade.
export default function BarraDistribuicao({ humor, quantidade, percentual }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  return (
    <View
      style={styles.linha}
      accessible
      accessibilityLabel={`${humor.nome}: ${quantidade} ${quantidade === 1 ? 'entrada' : 'entradas'}, ${percentual}%`}
    >
      <Text style={styles.emoji}>{humor.icone}</Text>
      <View style={styles.centro}>
        <View style={styles.rotulos}>
          <Text style={styles.nome}>{humor.nome}</Text>
          <Text style={styles.valor}>
            {quantidade} · {percentual}%
          </Text>
        </View>
        <View style={styles.trilho}>
          {quantidade > 0 ? (
            <View
              style={[
                styles.preenchimento,
                { width: `${Math.max(percentual, 4)}%`, backgroundColor: corDoHumor(humor.valor) },
              ]}
            />
          ) : null}
        </View>
      </View>
    </View>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  linha: { flexDirection: 'row', alignItems: 'center', marginBottom: espacos.sm + 2 },
  emoji: { fontSize: 26, width: 40 },
  centro: { flex: 1 },
  rotulos: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  nome: { fontSize: fontes.pequena + 1, color: cores.texto, fontWeight: '600' },
  valor: { fontSize: fontes.pequena, color: cores.textoSuave },
  trilho: {
    height: 10,
    borderRadius: raios.pilula,
    backgroundColor: cores.fundo,
    borderWidth: 1,
    borderColor: cores.borda,
    overflow: 'hidden',
  },
  preenchimento: { height: '100%', borderRadius: raios.pilula },
});
