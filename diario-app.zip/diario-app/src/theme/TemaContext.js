import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { temaPorId, temas, TEMA_PADRAO_ID } from './tema';
import * as temaStorage from '../models/temaStorage';

// Guarda o tema escolhido e entrega as cores para qualquer componente (useTema).
const TemaContext = createContext({
  tema: temas[0],
  cores: temas[0].cores,
  temas,
  escolherTema: () => {},
});

export function TemaProvider({ children }) {
  const [temaId, setTemaId] = useState(TEMA_PADRAO_ID);

  useEffect(() => {
    let ativo = true;
    temaStorage.lerTema().then((salvo) => {
      if (ativo && salvo) setTemaId(temaPorId(salvo).id);
    });
    return () => {
      ativo = false;
    };
  }, []);

  const valor = useMemo(() => {
    const tema = temaPorId(temaId);
    return {
      tema,
      cores: tema.cores,
      temas,
      escolherTema: (id) => {
        const novo = temaPorId(id).id;
        setTemaId(novo);
        temaStorage.salvarTema(novo);
      },
    };
  }, [temaId]);

  return <TemaContext.Provider value={valor}>{children}</TemaContext.Provider>;
}

export const useTema = () => useContext(TemaContext);
