import { Platform } from 'react-native';

// Cada tema é uma paleta completa. O tema "acolhedor" é o estilo original do app e é o padrão.
// textoSobrePrimaria: cor do texto/ícone sobre botões e caixas na cor primária.
// escuro: usado para decidir a cor dos ícones da barra de status.
export const temas = [
  {
    id: 'acolhedor',
    nome: 'Acolhedor',
    descricao: 'O estilo original: creme, terracota e verde-sálvia',
    escuro: false,
    cores: {
      fundo: '#FFF7EE', superficie: '#FFFFFF',
      primaria: '#E07A5F', primariaEscura: '#C65F44', primariaClara: '#FBE3DA', textoSobrePrimaria: '#FFFFFF',
      secundaria: '#81B29A', secundariaClara: '#E3F0E9', destaque: '#F2CC8F',
      texto: '#3D405B', textoSuave: '#7A7C93', borda: '#EBDDCF',
      erro: '#B03A2E', erroFundo: '#FDECEA', sucesso: '#2F6F51', sucessoFundo: '#E3F0E9',
      infoFundo: '#FDF1D8', infoTexto: '#7A5A1E', desabilitado: '#D9C9BC',
    },
  },
  {
    id: 'oceano',
    nome: 'Oceano',
    descricao: 'Azuis calmos, como um fim de tarde no mar',
    escuro: false,
    cores: {
      fundo: '#EEF6FB', superficie: '#FFFFFF',
      primaria: '#2A7DA8', primariaEscura: '#1F6389', primariaClara: '#D8EAF4', textoSobrePrimaria: '#FFFFFF',
      secundaria: '#6FB7A8', secundariaClara: '#DDF0EC', destaque: '#F4D58D',
      texto: '#25364A', textoSuave: '#5F7186', borda: '#D3E2EC',
      erro: '#B03A2E', erroFundo: '#FDECEA', sucesso: '#2A6B55', sucessoFundo: '#DDF0EC',
      infoFundo: '#FDF1D8', infoTexto: '#7A5A1E', desabilitado: '#BFCFDB',
    },
  },
  {
    id: 'floresta',
    nome: 'Floresta',
    descricao: 'Verdes profundos e tons de terra',
    escuro: false,
    cores: {
      fundo: '#F2F7EE', superficie: '#FFFFFF',
      primaria: '#3F7D4E', primariaEscura: '#2F6A3F', primariaClara: '#DCEBD6', textoSobrePrimaria: '#FFFFFF',
      secundaria: '#A9B97B', secundariaClara: '#EAF0DA', destaque: '#E9C46A',
      texto: '#2B3A2E', textoSuave: '#617063', borda: '#DAE5D2',
      erro: '#B03A2E', erroFundo: '#FDECEA', sucesso: '#2F6F3F', sucessoFundo: '#E1F0DC',
      infoFundo: '#FDF1D8', infoTexto: '#7A5A1E', desabilitado: '#C4D0BC',
    },
  },
  {
    id: 'lavanda',
    nome: 'Lavanda',
    descricao: 'Roxos suaves para desacelerar',
    escuro: false,
    cores: {
      fundo: '#F6F2FB', superficie: '#FFFFFF',
      primaria: '#7B5BB5', primariaEscura: '#634795', primariaClara: '#E7DDF5', textoSobrePrimaria: '#FFFFFF',
      secundaria: '#9EC5C0', secundariaClara: '#E1F0EE', destaque: '#F2D49B',
      texto: '#33294A', textoSuave: '#6E6585', borda: '#E4DCF0',
      erro: '#B03A2E', erroFundo: '#FDECEA', sucesso: '#2F6F51', sucessoFundo: '#E1F0EE',
      infoFundo: '#FDF1D8', infoTexto: '#7A5A1E', desabilitado: '#CFC6DC',
    },
  },
  {
    id: 'rosa',
    nome: 'Rosa',
    descricao: 'Rosas delicados e pêssego',
    escuro: false,
    cores: {
      fundo: '#FFF3F6', superficie: '#FFFFFF',
      primaria: '#C2417A', primariaEscura: '#A5336A', primariaClara: '#FADDE8', textoSobrePrimaria: '#FFFFFF',
      secundaria: '#F2A99B', secundariaClara: '#FCE6E0', destaque: '#F7D58B',
      texto: '#4A2E3D', textoSuave: '#85657A', borda: '#F2DAE3',
      erro: '#A12D3A', erroFundo: '#FDECEA', sucesso: '#2F6F51', sucessoFundo: '#E3F0E9',
      infoFundo: '#FDF1D8', infoTexto: '#7A5A1E', desabilitado: '#DCC6CF',
    },
  },
  {
    id: 'cafe',
    nome: 'Café',
    descricao: 'Marrons quentes e creme, como uma cafeteria',
    escuro: false,
    cores: {
      fundo: '#F8F1E9', superficie: '#FFFDF9',
      primaria: '#8B5A3C', primariaEscura: '#704529', primariaClara: '#EBDACB', textoSobrePrimaria: '#FFFFFF',
      secundaria: '#B7A27D', secundariaClara: '#EFE7D6', destaque: '#E3B87F',
      texto: '#3F2F25', textoSuave: '#77665A', borda: '#E6D9CB',
      erro: '#A83A2E', erroFundo: '#FBEAE6', sucesso: '#3D6B45', sucessoFundo: '#E4EEDC',
      infoFundo: '#F9EBCB', infoTexto: '#6E4F14', desabilitado: '#D3C6B8',
    },
  },
  {
    id: 'menta',
    nome: 'Menta',
    descricao: 'Verde-água fresco e leve',
    escuro: false,
    cores: {
      fundo: '#EEF9F7', superficie: '#FFFFFF',
      primaria: '#0F7F83', primariaEscura: '#0B666A', primariaClara: '#D2EEEC', textoSobrePrimaria: '#FFFFFF',
      secundaria: '#8CCFB9', secundariaClara: '#DFF3EC', destaque: '#F5D98B',
      texto: '#1F3B3D', textoSuave: '#58757A', borda: '#CFE8E5',
      erro: '#B03A2E', erroFundo: '#FDECEA', sucesso: '#25684E', sucessoFundo: '#DFF3EC',
      infoFundo: '#FDF1D8', infoTexto: '#7A5A1E', desabilitado: '#B9D3D0',
    },
  },
  {
    id: 'grafite',
    nome: 'Grafite',
    descricao: 'Tons de cinza com alto contraste',
    escuro: false,
    cores: {
      fundo: '#F4F4F5', superficie: '#FFFFFF',
      primaria: '#3E4756', primariaEscura: '#2A313D', primariaClara: '#E1E4E9', textoSobrePrimaria: '#FFFFFF',
      secundaria: '#8A94A3', secundariaClara: '#E6E9ED', destaque: '#D9C27A',
      texto: '#1E232B', textoSuave: '#59616E', borda: '#DADDE2',
      erro: '#A62E22', erroFundo: '#FBE9E7', sucesso: '#256445', sucessoFundo: '#E0EFE7',
      infoFundo: '#F7EDC9', infoTexto: '#5E4710', desabilitado: '#C3C8D0',
    },
  },
  {
    id: 'noite',
    nome: 'Noite',
    descricao: 'Tema escuro, confortável para usar à noite',
    escuro: true,
    cores: {
      fundo: '#171923', superficie: '#222536',
      primaria: '#F0A183', primariaEscura: '#F4B59C', primariaClara: '#3A2E36', textoSobrePrimaria: '#2A1A14',
      secundaria: '#7FB59C', secundariaClara: '#223A33', destaque: '#E7C27D',
      texto: '#ECEAF5', textoSuave: '#A6A8BE', borda: '#34374B',
      erro: '#FF9A8F', erroFundo: '#3E2428', sucesso: '#8AD2AE', sucessoFundo: '#1F3A30',
      infoFundo: '#3B3220', infoTexto: '#F0CF8E', desabilitado: '#4A4D63',
    },
  },
];

export const TEMA_PADRAO_ID = 'acolhedor';
export const temaPorId = (id) => temas.find((t) => t.id === id) || temas[0];

// Paleta do tema padrão (mantida para quem importa "cores" direto; as telas usam useTema()).
export const cores = temas[0].cores;

// Cor de cada humor pelo valor (1 a 5): do azul calmo ao terracota caloroso.
const coresHumor = { 1: '#8FA3BF', 2: '#B7A6C8', 3: '#F2CC8F', 4: '#F4A261', 5: '#E07A5F' };
export function corDoHumor(valor) {
  return coresHumor[Math.round(valor)] || cores.destaque;
}

export const espacos = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32 };
export const raios = { sm: 10, md: 16, lg: 24, pilula: 999 };
export const fontes = { titulo: 28, subtitulo: 20, corpo: 16, pequena: 13, minima: 11 };

export const sombra = Platform.select({
  ios: {
    shadowColor: '#8A5A44',
    shadowOpacity: 0.12,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
  },
  android: { elevation: 3 },
  default: { boxShadow: '0px 4px 14px rgba(138, 90, 68, 0.12)' },
});

// Largura máxima do conteúdo (mantém o layout agradável em tablets e no navegador).
export const larguraMaxima = 560;
