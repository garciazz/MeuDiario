// Datas são trabalhadas como texto 'AAAA-MM-DD' no fuso local do aparelho,
// o mesmo formato usado pela API (evita erros de fuso horário do toISOString).

const DIAS_DA_SEMANA = [
  'domingo',
  'segunda-feira',
  'terça-feira',
  'quarta-feira',
  'quinta-feira',
  'sexta-feira',
  'sábado',
];

const doisDigitos = (n) => String(n).padStart(2, '0');

function partes(iso) {
  const [ano, mes, dia] = iso.split('-').map(Number);
  return { ano, mes, dia };
}

export function paraISO(data) {
  return `${data.getFullYear()}-${doisDigitos(data.getMonth() + 1)}-${doisDigitos(data.getDate())}`;
}

export function hojeISO() {
  return paraISO(new Date());
}

export function somarDias(iso, quantidade) {
  const { ano, mes, dia } = partes(iso);
  return paraISO(new Date(ano, mes - 1, dia + quantidade));
}

// Lista de n dias em ordem crescente, terminando em "fim" (por padrão, hoje).
export function ultimosDias(n, fim = hojeISO()) {
  const lista = [];
  for (let i = n - 1; i >= 0; i -= 1) lista.push(somarDias(fim, -i));
  return lista;
}

export function formatarBR(iso) {
  const { ano, mes, dia } = partes(iso);
  return `${doisDigitos(dia)}/${doisDigitos(mes)}/${ano}`;
}

export function rotuloCurto(iso) {
  const { mes, dia } = partes(iso);
  return `${doisDigitos(dia)}/${doisDigitos(mes)}`;
}

function nomeDoDia(iso) {
  const { ano, mes, dia } = partes(iso);
  const nome = DIAS_DA_SEMANA[new Date(ano, mes - 1, dia).getDay()];
  return nome.charAt(0).toUpperCase() + nome.slice(1);
}

// "Hoje", "Ontem" ou "Sexta-feira, 21/11".
export function rotuloRelativo(iso, hoje = hojeISO()) {
  if (iso === hoje) return 'Hoje';
  if (iso === somarDias(hoje, -1)) return 'Ontem';
  return `${nomeDoDia(iso)}, ${rotuloCurto(iso)}`;
}

export function dataCompletaAmigavel(iso) {
  return `${nomeDoDia(iso)}, ${formatarBR(iso)}`;
}

// Máscara de digitação: "22112026" -> "22/11/2026".
export function mascaraDataBR(texto) {
  const digitos = texto.replace(/\D/g, '').slice(0, 8);
  if (digitos.length <= 2) return digitos;
  if (digitos.length <= 4) return `${digitos.slice(0, 2)}/${digitos.slice(2)}`;
  return `${digitos.slice(0, 2)}/${digitos.slice(2, 4)}/${digitos.slice(4)}`;
}

// "22/11/1995" -> "1995-11-22". Retorna null se a data não existir, for futura ou anterior a 1900.
export function brParaISO(texto) {
  const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(texto);
  if (!m) return null;
  const dia = Number(m[1]);
  const mes = Number(m[2]);
  const ano = Number(m[3]);
  const data = new Date(ano, mes - 1, dia);
  const existe = data.getFullYear() === ano && data.getMonth() === mes - 1 && data.getDate() === dia;
  if (!existe || ano < 1900) return null;
  const iso = paraISO(data);
  return iso <= hojeISO() ? iso : null;
}
