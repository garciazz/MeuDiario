import { formatarBR } from './datas';

// Monta o HTML do relatório em PDF. Função pura (sem tela, sem API): só recebe os números já calculados.
// O PDF não leva o texto das entradas: só o resumo, como na tela Relatório.

function esc(valor) {
  return String(valor ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

const CORES_HUMOR = { 1: '#8FA3BF', 2: '#B7A6C8', 3: '#F2CC8F', 4: '#F4A261', 5: '#E07A5F' };
const corHumor = (valor) => CORES_HUMOR[Math.round(valor)] || '#F2CC8F';
const decimal = (n) => n.toFixed(1).replace('.', ',');

function dataHoraBR(data) {
  const dois = (n) => String(n).padStart(2, '0');
  const iso = `${data.getFullYear()}-${dois(data.getMonth() + 1)}-${dois(data.getDate())}`;
  return `${formatarBR(iso)} às ${dois(data.getHours())}:${dois(data.getMinutes())}`;
}

// Nome do arquivo: relatorio-diario-30-dias-2026-11-22.pdf
export function nomeDoArquivoPdf(dias, hojeISOtexto) {
  return `relatorio-diario-${dias}-dias-${hojeISOtexto}.pdf`;
}

export function montarHtmlRelatorio({ nomeUsuario, relatorio, mensagemApoio, geradoEm = new Date() }) {
  const r = relatorio;
  const inicio = r.serie[0].data;
  const fim = r.serie[r.serie.length - 1].data;

  const distribuicao = r.distribuicao
    .map(
      (item) => `
      <tr>
        <td class="emo">${esc(item.humor.icone)} ${esc(item.humor.nome)}</td>
        <td class="barra"><div class="trilho"><div class="preenche" style="width:${item.percentual}%;background:${corHumor(item.humor.valor)}"></div></div></td>
        <td class="num">${item.quantidade} (${item.percentual}%)</td>
      </tr>`
    )
    .join('');

  // Gráfico dia a dia: uma coluna por dia (altura = humor médio, de 1 a 5). Dias sem registro ficam vazios.
  const colunas = r.serie
    .map((dia) => {
      const altura = dia.media ? Math.round((dia.media / 5) * 100) : 0;
      return `<div class="col"><div class="coluna" style="height:${altura}%;background:${dia.media ? corHumor(dia.media) : 'transparent'}"></div></div>`;
    })
    .join('');
  const pontaEsquerda = formatarBR(inicio).slice(0, 5);
  const pontaDireita = formatarBR(fim).slice(0, 5);

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Relatório do Meu Diário - ${r.dias} dias</title>
<style>
  @page { margin: 18mm 14mm; }
  * { box-sizing: border-box; }
  body { font-family: -apple-system, 'Helvetica Neue', Arial, sans-serif; color: #3D405B; margin: 0; padding: 0; font-size: 13px; line-height: 1.45; }
  h1 { font-size: 24px; margin: 0 0 4px; color: #C65F44; }
  h2 { font-size: 16px; margin: 22px 0 8px; }
  .sub { color: #7A7C93; margin: 0; }
  .topo { border-bottom: 3px solid #E07A5F; padding-bottom: 12px; margin-bottom: 16px; }
  .resumo { display: flex; gap: 10px; }
  .card { flex: 1; background: #FFF7EE; border: 1px solid #EBDDCF; border-radius: 12px; padding: 12px; text-align: center; }
  .card b { display: block; font-size: 26px; color: #3D405B; }
  .card span { color: #7A7C93; font-size: 12px; }
  .apoio { background: #FDF1D8; color: #7A5A1E; border-radius: 12px; padding: 12px; margin-top: 14px; font-weight: 600; }
  table { width: 100%; border-collapse: collapse; }
  td { padding: 5px 4px; vertical-align: middle; }
  td.emo { width: 32%; white-space: nowrap; }
  td.num { width: 22%; text-align: right; color: #7A7C93; }
  .trilho { height: 12px; background: #F3E9DE; border-radius: 6px; overflow: hidden; }
  .preenche { height: 100%; border-radius: 6px; }
  .grafico { display: flex; align-items: flex-end; gap: 2px; height: 110px; border-bottom: 1px solid #EBDDCF; padding: 0 2px; }
  .col { flex: 1; height: 100%; display: flex; align-items: flex-end; }
  .coluna { width: 100%; border-radius: 3px 3px 0 0; }
  .eixo { display: flex; justify-content: space-between; color: #7A7C93; font-size: 11px; margin-top: 4px; }
  .vazio { color: #7A7C93; text-align: center; padding: 24px 0; }
  .rodape { margin-top: 26px; padding-top: 10px; border-top: 1px solid #EBDDCF; color: #7A7C93; font-size: 11px; }
  .quebra { page-break-inside: avoid; }
</style>
</head>
<body>
  <div class="topo">
    <h1>Meu Diário · Relatório de ${r.dias} dias</h1>
    <p class="sub">${esc(nomeUsuario)} · de ${formatarBR(inicio)} a ${formatarBR(fim)}</p>
  </div>

  ${
    r.total === 0
      ? '<p class="vazio">Não há entradas neste período.</p>'
      : `
  <div class="resumo quebra">
    <div class="card"><b>${r.total}</b><span>${r.total === 1 ? 'Entrada' : 'Entradas'}</span></div>
    <div class="card"><b>${decimal(r.mediaHumor)} ${r.humorMedio ? esc(r.humorMedio.icone) : ''}</b><span>Humor médio${r.humorMedio ? ` (${esc(r.humorMedio.nome)})` : ''}</span></div>
    <div class="card"><b>${r.sequencia}</b><span>${r.sequencia === 1 ? 'Dia seguido' : 'Dias seguidos'}</span></div>
  </div>
  <p class="sub" style="margin-top:8px">${r.diasComRegistro} de ${r.dias} dias com registro.</p>

  ${mensagemApoio ? `<div class="apoio quebra">${esc(mensagemApoio)}</div>` : ''}

  <h2>Como você se sentiu</h2>
  <table class="quebra">${distribuicao}</table>

  <h2>Dia a dia</h2>
  <div class="quebra">
    <div class="grafico">${colunas}</div>
    <div class="eixo"><span>${pontaEsquerda}</span><span>${pontaDireita}</span></div>
    <p class="sub" style="margin-top:6px">Humor médio de cada dia: quanto mais alta a coluna, mais leve foi o dia.</p>
  </div>`
  }

  <div class="rodape">
    Gerado em ${dataHoraBR(geradoEm)}. Este documento contém dados pessoais sensíveis sobre o seu bem-estar emocional: guarde-o e
    compartilhe-o com cuidado. Não substitui avaliação de um profissional de saúde.
  </div>
</body>
</html>`;
}
