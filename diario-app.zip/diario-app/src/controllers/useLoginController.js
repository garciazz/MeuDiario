import { useState } from 'react';
import { useAuth } from './AuthContext';

export default function useLoginController() {
  const { entrar } = useAuth();
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');
  const [enviando, setEnviando] = useState(false);

  async function enviar() {
    if (enviando) return;
    if (!email.trim() || !senha) {
      setErro('Informe seu e-mail e sua senha.');
      return;
    }
    setErro('');
    setEnviando(true);
    try {
      await entrar(email.trim(), senha);
      // Ao entrar, a tela de login é substituída pelo diário.
    } catch (e) {
      setErro(e.message);
      setEnviando(false);
    }
  }

  return { email, setEmail, senha, setSenha, erro, enviando, enviar };
}
