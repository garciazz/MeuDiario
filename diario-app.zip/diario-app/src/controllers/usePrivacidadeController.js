import { useState } from 'react';
import { useAuth } from './AuthContext';

// Tela Privacidade: situação do aceite e retirada da autorização (exclui a conta, com confirmação por senha).
export default function usePrivacidadeController() {
  const { usuario, excluirConta } = useAuth();
  const [confirmando, setConfirmando] = useState(false);
  const [senha, setSenha] = useState('');
  const [erroSenha, setErroSenha] = useState('');
  const [erro, setErro] = useState('');
  const [excluindo, setExcluindo] = useState(false);

  function iniciar() {
    setConfirmando(true);
    setSenha('');
    setErroSenha('');
    setErro('');
  }

  function cancelar() {
    setConfirmando(false);
    setSenha('');
    setErroSenha('');
    setErro('');
  }

  async function confirmar() {
    if (excluindo) return;
    if (!senha) {
      setErroSenha('Digite a sua senha para confirmar.');
      return;
    }
    setExcluindo(true);
    setErroSenha('');
    setErro('');
    try {
      await excluirConta(senha);
      // Conta apagada: o navegador volta para o login.
    } catch (e) {
      if (e.detalhes?.senha) setErroSenha(e.detalhes.senha);
      else setErro(e.message);
      setExcluindo(false);
    }
  }

  return {
    consentimento: usuario?.consentimento,
    confirmando,
    iniciar,
    cancelar,
    senha,
    setSenha,
    erroSenha,
    erro,
    excluindo,
    confirmar,
  };
}
