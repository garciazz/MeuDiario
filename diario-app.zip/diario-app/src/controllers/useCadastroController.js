import { useEffect, useState } from 'react';
import { useAuth } from './AuthContext';
import useTermos from './useTermos';
import * as catalogoModel from '../models/catalogoModel';
import { brParaISO, mascaraDataBR } from '../utils/datas';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Nome do campo na API -> nome do campo no formulário.
const CAMPOS_DA_API = {
  nome: 'nome',
  email: 'email',
  senha: 'senha',
  data_nascimento: 'dataNascimento',
  areas_interesse: 'areas',
  consentimento: 'consentimento',
};

export default function useCadastroController() {
  const { cadastrar } = useAuth();
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');
  const [dataNascimento, setDataNascimentoTexto] = useState('');
  const [areasSelecionadas, setAreasSelecionadas] = useState([]);
  const termosDados = useTermos();
  // A autorização começa desmarcada e vem ANTES das áreas de interesse, que também são dados sensíveis.
  const [autorizou, setAutorizouEstado] = useState(false);

  const [areas, setAreas] = useState([]);
  const [carregandoAreas, setCarregandoAreas] = useState(true);
  const [erroAreas, setErroAreas] = useState('');

  const [erros, setErros] = useState({});
  const [erroGeral, setErroGeral] = useState('');
  const [enviando, setEnviando] = useState(false);

  useEffect(() => {
    let ativo = true;
    catalogoModel
      .listarAreasInteresse()
      .then((lista) => {
        if (ativo) setAreas(lista);
      })
      .catch(() => {
        // As áreas são opcionais: o cadastro continua possível sem elas.
        if (ativo) setErroAreas('Não foi possível carregar as áreas de interesse agora.');
      })
      .finally(() => {
        if (ativo) setCarregandoAreas(false);
      });
    return () => {
      ativo = false;
    };
  }, []);

  function setDataNascimento(texto) {
    setDataNascimentoTexto(mascaraDataBR(texto));
  }

  function setAutorizou(valor) {
    setAutorizouEstado(valor);
    if (!valor) setAreasSelecionadas([]); // sem autorização, nenhuma área é guardada
  }

  function alternarArea(id) {
    if (!autorizou) return;
    setAreasSelecionadas((atuais) =>
      atuais.includes(id) ? atuais.filter((x) => x !== id) : [...atuais, id]
    );
  }

  function validar() {
    const novos = {};
    if (nome.trim().length < 2) novos.nome = 'Informe seu nome.';
    if (!EMAIL_RE.test(email.trim())) novos.email = 'Informe um e-mail válido.';
    if (senha.length < 8) novos.senha = 'A senha deve ter pelo menos 8 caracteres.';
    if (confirmarSenha !== senha) novos.confirmarSenha = 'As senhas não são iguais.';
    if (dataNascimento && !brParaISO(dataNascimento)) {
      novos.dataNascimento = 'Use uma data válida no formato DD/MM/AAAA.';
    }
    if (autorizou && !termosDados.termos) novos.consentimento = 'Aguarde o aviso carregar para autorizar.';
    return novos;
  }

  async function enviar() {
    if (enviando) return;
    const novos = validar();
    setErros(novos);
    setErroGeral('');
    if (Object.keys(novos).length) return;

    setEnviando(true);
    try {
      await cadastrar({
        nome: nome.trim(),
        email: email.trim(),
        senha,
        dataNascimento: brParaISO(dataNascimento) || undefined,
        areas: autorizou ? areasSelecionadas : [],
        consentimento: autorizou ? { versao: termosDados.termos.versao, aceito: true } : undefined,
      });
      // Conta criada: o app já entra logado.
    } catch (e) {
      const doServidor = {};
      Object.entries(e.detalhes || {}).forEach(([campo, mensagem]) => {
        if (CAMPOS_DA_API[campo]) doServidor[CAMPOS_DA_API[campo]] = mensagem;
      });
      if (Object.keys(doServidor).length) setErros(doServidor);
      else if (e.status === 409) setErros({ email: e.message });
      else setErroGeral(e.message);
      setEnviando(false);
    }
  }

  return {
    nome,
    setNome,
    email,
    setEmail,
    senha,
    setSenha,
    confirmarSenha,
    setConfirmarSenha,
    dataNascimento,
    setDataNascimento,
    areas,
    areasSelecionadas,
    alternarArea,
    termos: termosDados.termos,
    carregandoTermos: termosDados.carregando,
    erroTermos: termosDados.erro,
    tentarTermosDeNovo: termosDados.tentarDeNovo,
    autorizou,
    setAutorizou,
    carregandoAreas,
    erroAreas,
    erros,
    erroGeral,
    enviando,
    enviar,
  };
}
