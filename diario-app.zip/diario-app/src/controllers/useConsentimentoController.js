import { useState } from 'react';
import { useAuth } from './AuthContext';
import useTermos from './useTermos';

// Tela de consentimento: a caixa começa desmarcada e "Concordo e continuar" só vale com ela marcada.
export default function useConsentimentoController() {
  const { aceitarTermos, sair } = useAuth();
  const dados = useTermos();
  const [marcada, setMarcada] = useState(false);
  const [recusou, setRecusou] = useState(false);
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState('');

  async function concordar() {
    if (!marcada || enviando || !dados.termos) return;
    setEnviando(true);
    setErro('');
    try {
      await aceitarTermos(dados.termos.versao);
      // Aceite registrado: o navegador libera o diário sozinho.
    } catch (e) {
      setErro(e.message);
      setEnviando(false);
    }
  }

  return {
    ...dados,
    marcada,
    setMarcada: (valor) => {
      setMarcada(valor);
      if (valor) setRecusou(false);
    },
    recusou,
    recusar: () => setRecusou(true),
    enviando,
    erro,
    concordar,
    sair,
  };
}
