import { useEffect, useState } from 'react';
import * as catalogoModel from '../models/catalogoModel';
import * as entradaModel from '../models/entradaModel';
import { useAuth } from './AuthContext';
import { hojeISO } from '../utils/datas';

const POR_PAGINA = 20;

export default function useDiarioController() {
  const { consentimentoPerdido } = useAuth();
  const [humores, setHumores] = useState([]);
  const [carregandoHumores, setCarregandoHumores] = useState(true);
  const [erroHumores, setErroHumores] = useState('');

  const [entradas, setEntradas] = useState([]);
  const [total, setTotal] = useState(0);
  const [carregandoLista, setCarregandoLista] = useState(true);
  const [carregandoMais, setCarregandoMais] = useState(false);
  const [atualizando, setAtualizando] = useState(false);
  const [erroLista, setErroLista] = useState('');

  const [humorId, setHumorId] = useState(null);
  const [fezBem, setFezBem] = useState('');
  const [fezMal, setFezMal] = useState('');
  const [aprendeu, setAprendeu] = useState('');
  const [salvando, setSalvando] = useState(false);
  const [erroForm, setErroForm] = useState('');
  const [mensagemSucesso, setMensagemSucesso] = useState('');

  async function carregarHumores() {
    setErroHumores('');
    setCarregandoHumores(true);
    try {
      setHumores(await catalogoModel.listarHumores());
    } catch (e) {
      setErroHumores(e.message);
    } finally {
      setCarregandoHumores(false);
    }
  }

  async function carregarPrimeiraPagina() {
    setErroLista('');
    try {
      const { entradas: itens, paginacao } = await entradaModel.listar({ limite: POR_PAGINA });
      setEntradas(itens);
      setTotal(paginacao.total);
    } catch (e) {
      setErroLista(e.message);
    }
  }

  useEffect(() => {
    carregarHumores();
    carregarPrimeiraPagina().finally(() => setCarregandoLista(false));
  }, []);

  // Some sozinha a mensagem de "entrada salva".
  useEffect(() => {
    if (!mensagemSucesso) return undefined;
    const cronometro = setTimeout(() => setMensagemSucesso(''), 4000);
    return () => clearTimeout(cronometro);
  }, [mensagemSucesso]);

  async function atualizar() {
    setAtualizando(true);
    if (!humores.length) await carregarHumores();
    await carregarPrimeiraPagina();
    setAtualizando(false);
  }

  async function carregarMais() {
    if (carregandoLista || carregandoMais || entradas.length >= total) return;
    setCarregandoMais(true);
    try {
      const { entradas: itens, paginacao } = await entradaModel.listar({
        limite: POR_PAGINA,
        offset: entradas.length,
      });
      setEntradas((atuais) => [...atuais, ...itens]);
      setTotal(paginacao.total);
    } catch (e) {
      setErroLista(e.message);
    } finally {
      setCarregandoMais(false);
    }
  }

  async function salvar() {
    if (salvando) return;
    if (!humorId) {
      setErroForm('Escolha como você está se sentindo.');
      return;
    }
    if (!fezBem.trim() && !fezMal.trim() && !aprendeu.trim()) {
      setErroForm('Escreva ao menos uma das respostas para salvar.');
      return;
    }
    setErroForm('');
    setSalvando(true);
    try {
      await entradaModel.criar({
        humorId,
        fezBem: fezBem.trim(),
        fezMal: fezMal.trim(),
        aprendeu: aprendeu.trim(),
        dataEntrada: hojeISO(), // data local do aparelho
      });
      setHumorId(null);
      setFezBem('');
      setFezMal('');
      setAprendeu('');
      setMensagemSucesso('Entrada salva no seu diário. 🌼');
      await carregarPrimeiraPagina();
    } catch (e) {
      // O Termo mudou de versão durante o uso: o app volta para a tela de autorização.
      if (e.codigo === 'CONSENTIMENTO_NECESSARIO') consentimentoPerdido();
      setErroForm(e.message);
    } finally {
      setSalvando(false);
    }
  }

  return {
    humores,
    carregandoHumores,
    erroHumores,
    recarregarHumores: carregarHumores,
    entradas,
    total,
    carregandoLista,
    carregandoMais,
    atualizando,
    erroLista,
    atualizar,
    carregarMais,
    humorId,
    setHumorId,
    fezBem,
    setFezBem,
    fezMal,
    setFezMal,
    aprendeu,
    setAprendeu,
    salvando,
    erroForm,
    mensagemSucesso,
    salvar,
  };
}
