import { useEffect, useState } from 'react';
import * as termosModel from '../models/termosModel';

// Carrega o aviso, o Termo e a Política (texto vem da API, na versão vigente).
export default function useTermos() {
  const [termos, setTermos] = useState(null);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');
  const [tentativa, setTentativa] = useState(0);

  useEffect(() => {
    let ativo = true;
    setCarregando(true);
    setErro('');
    termosModel
      .buscarTermos({ forcar: tentativa > 0 })
      .then((dados) => {
        if (ativo) setTermos(dados);
      })
      .catch((e) => {
        if (ativo) setErro(e.message);
      })
      .finally(() => {
        if (ativo) setCarregando(false);
      });
    return () => {
      ativo = false;
    };
  }, [tentativa]);

  return { termos, carregando, erro, tentarDeNovo: () => setTentativa((n) => n + 1) };
}
