import { createContext, useContext, useEffect, useState } from 'react';
import * as authModel from '../models/authModel';
import * as termosModel from '../models/termosModel';
import { definirAoExpirarSessao } from '../models/http';

// Guarda quem está logado e expõe entrar / cadastrar / sair para qualquer tela.
const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [usuario, setUsuario] = useState(null);
  const [carregandoSessao, setCarregandoSessao] = useState(true);

  useEffect(() => {
    let ativo = true;
    // Se a sessão não puder ser renovada, volta para a tela de login.
    definirAoExpirarSessao(() => setUsuario(null));

    authModel
      .restaurarSessao()
      .then((usuarioSalvo) => {
        if (ativo) setUsuario(usuarioSalvo);
      })
      .finally(() => {
        if (ativo) setCarregandoSessao(false);
      });

    return () => {
      ativo = false;
    };
  }, []);

  async function entrar(email, senha) {
    setUsuario(await authModel.login(email, senha));
  }

  async function cadastrar(dados) {
    setUsuario(await authModel.cadastrar(dados));
  }

  // Aceite do Termo (tela de consentimento): atualiza o usuário em memória com a nova situação.
  async function aceitarTermos(versao) {
    const consentimento = await termosModel.aceitar(versao);
    setUsuario((atual) => (atual ? { ...atual, consentimento } : atual));
  }

  // A API recusou uma gravação por falta de aceite (ex.: Termo mudou de versão): volta para a tela de consentimento.
  function consentimentoPerdido() {
    setUsuario((atual) =>
      atual ? { ...atual, consentimento: { ...atual.consentimento, vigente: false } } : atual
    );
  }

  // Retirar a autorização: exclui a conta (com a senha) e volta para o login.
  async function excluirConta(senha) {
    await authModel.excluirConta(senha);
    setUsuario(null);
  }

  async function sair() {
    await authModel.logout();
    setUsuario(null);
  }

  return (
    <AuthContext.Provider value={{
        usuario,
        carregandoSessao,
        entrar,
        cadastrar,
        sair,
        aceitarTermos,
        consentimentoPerdido,
        excluirConta,
      }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const contexto = useContext(AuthContext);
  if (!contexto) throw new Error('useAuth precisa ser usado dentro de <AuthProvider>.');
  return contexto;
}
