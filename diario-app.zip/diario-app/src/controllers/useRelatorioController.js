import { useEffect, useState } from 'react';
import * as catalogoModel from '../models/catalogoModel';
import * as entradaModel from '../models/entradaModel';
import { calcularRelatorio, mensagemDeApoio, PERIODOS } from '../models/relatorioModel';
import * as pdfModel from '../models/pdfModel';
import { montarHtmlRelatorio, nomeDoArquivoPdf } from '../utils/relatorioPdf';
import { useAuth } from './AuthContext';
import { hojeISO, somarDias } from '../utils/datas';

const DIAS_BUSCADOS = Math.max(...PERIODOS.map((p) => p.dias));

export default function useRelatorioController() {
  const { usuario } = useAuth();
  const [gerandoPdf, setGerandoPdf] = useState(false);
  const [erroPdf, setErroPdf] = useState('');
  const [humores, setHumores] = useState([]);
  const [entradas, setEntradas] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [atualizando, setAtualizando] = useState(false);
  const [erro, setErro] = useState('');
  const [periodo, setPeriodo] = useState(PERIODOS[0].dias);

  // Busca uma vez os últimos 90 dias; trocar o período só recalcula, sem nova chamada.
  async function carregar() {
    setErro('');
    try {
      const hoje = hojeISO();
      const [listaHumores, listaEntradas] = await Promise.all([
        catalogoModel.listarHumores(),
        entradaModel.listarDoPeriodo(somarDias(hoje, -(DIAS_BUSCADOS - 1)), hoje),
      ]);
      setHumores(listaHumores);
      setEntradas(listaEntradas);
    } catch (e) {
      setErro(e.message);
    }
  }

  useEffect(() => {
    carregar().finally(() => setCarregando(false));
  }, []);

  async function atualizar() {
    setAtualizando(true);
    await carregar();
    setAtualizando(false);
  }

  async function tentarNovamente() {
    setCarregando(true);
    await carregar();
    setCarregando(false);
  }

  // Gera o PDF do período selecionado (7, 30 ou 90 dias) e abre para a pessoa.
  // O HTML é montado antes de qualquer "await": na web, a janela precisa abrir direto no toque.
  async function gerarPdf() {
    if (gerandoPdf || !relatorio || relatorio.total === 0) return;
    setErroPdf('');
    setGerandoPdf(true);
    try {
      const html = montarHtmlRelatorio({
        nomeUsuario: usuario?.nome || '',
        relatorio,
        mensagemApoio: mensagemDeApoio(relatorio.mediaHumor),
      });
      await pdfModel.gerarEAbrirPdf({ html, nomeArquivo: nomeDoArquivoPdf(periodo, hojeISO()) });
    } catch (e) {
      setErroPdf(e.message || 'Não foi possível gerar o PDF. Tente novamente.');
    } finally {
      setGerandoPdf(false);
    }
  }

  const relatorio = humores.length ? calcularRelatorio(entradas, humores, periodo) : null;

  return {
    periodo,
    setPeriodo,
    relatorio,
    mensagemApoio: relatorio ? mensagemDeApoio(relatorio.mediaHumor) : '',
    carregando,
    atualizando,
    erro,
    atualizar,
    tentarNovamente,
    gerarPdf,
    gerandoPdf,
    erroPdf,
  };
}
