import { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import TelaBase from '../components/TelaBase';
import ConteudoRolavel from '../components/ConteudoRolavel';
import LogoMarca from '../components/LogoMarca';
import Cartao from '../components/Cartao';
import CampoTexto from '../components/CampoTexto';
import Botao from '../components/Botao';
import MensagemFeedback from '../components/MensagemFeedback';
import useLoginController from '../controllers/useLoginController';
import { espacos, fontes } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

export default function LoginScreen({ onIrParaCadastro, onAbrirDocumento }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  const c = useLoginController();

  return (
    <TelaBase edges={['top', 'bottom', 'left', 'right']}>
      <ConteudoRolavel>
        <LogoMarca />
        <Cartao>
          <Text style={styles.titulo}>Que bom ter você aqui</Text>
          <Text style={styles.subtitulo}>Entre para continuar o seu diário.</Text>

          <MensagemFeedback texto={c.erro} />

          <CampoTexto
            rotulo="E-mail"
            value={c.email}
            onChangeText={c.setEmail}
            placeholder="voce@exemplo.com"
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            autoComplete="email"
            returnKeyType="next"
          />
          <CampoTexto
            rotulo="Senha"
            senha
            value={c.senha}
            onChangeText={c.setSenha}
            placeholder="Sua senha"
            autoCapitalize="none"
            autoComplete="current-password"
            returnKeyType="go"
            onSubmitEditing={c.enviar}
          />

          <Botao titulo="Entrar" onPress={c.enviar} carregando={c.enviando} />
        </Cartao>

        <View style={styles.rodape}>
          <Text style={styles.rodapeTexto}>Ainda não tem uma conta?</Text>
          <Botao titulo="Criar minha conta" variante="secundario" onPress={onIrParaCadastro} />
          <View style={styles.legal}>
            <Botao titulo="Termo de Autorização" variante="link" onPress={() => onAbrirDocumento('termo')} />
            <Botao titulo="Política de Privacidade" variante="link" onPress={() => onAbrirDocumento('politica')} />
          </View>
        </View>
      </ConteudoRolavel>
    </TelaBase>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  titulo: { fontSize: fontes.subtitulo, fontWeight: '800', color: cores.texto },
  subtitulo: { fontSize: fontes.corpo, color: cores.textoSuave, marginTop: 4, marginBottom: espacos.md },
  rodape: { marginTop: espacos.sm, gap: espacos.sm },
  legal: { flexDirection: 'row', justifyContent: 'center', flexWrap: 'wrap' },
  rodapeTexto: { textAlign: 'center', color: cores.textoSuave, fontSize: fontes.corpo },
});
