import { useMemo } from 'react';
import { FlatList, StyleSheet, Text, View } from 'react-native';
import TelaBase from '../components/TelaBase';
import { estiloConteudoCentral } from '../components/ConteudoRolavel';
import Cartao from '../components/Cartao';
import Botao from '../components/Botao';
import Carregando from '../components/Carregando';
import MensagemFeedback from '../components/MensagemFeedback';
import { Bloco } from '../components/BlocosDeTexto';
import useTermos from '../controllers/useTermos';
import { espacos, fontes } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

// Mostra o Termo de Autorização ou a Política de Privacidade (qual = 'termo' | 'politica').
// A lista de blocos é uma FlatList: o texto é longo e rola.
export default function DocumentoScreen({ qual, onVoltar }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  const { termos, carregando, erro, tentarDeNovo } = useTermos();
  const documento = termos ? (qual === 'termo' ? termos.termo : termos.politica) : null;

  const topo = (
    <View>
      <Botao titulo="‹ Voltar" variante="link" onPress={onVoltar} style={styles.voltar} />
      <Text style={styles.titulo} accessibilityRole="header">
        {documento ? documento.titulo : qual === 'termo' ? 'Termo de Autorização' : 'Política de Privacidade'}
      </Text>
      {termos ? <Text style={styles.versao}>Versão {termos.versao}, vigente desde {termos.vigente_desde}</Text> : null}
      {carregando ? <Carregando mensagem="Carregando o texto..." /> : null}
      {erro ? (
        <View>
          <MensagemFeedback texto={erro} />
          <Botao titulo="Tentar de novo" variante="secundario" onPress={tentarDeNovo} />
        </View>
      ) : null}
    </View>
  );

  return (
    <TelaBase edges={['top', 'bottom', 'left', 'right']}>
      <FlatList
        data={documento ? documento.blocos : []}
        keyExtractor={(_, i) => String(i)}
        initialNumToRender={80} // o texto inteiro fica disponível (leitores de tela, busca na página)
        renderItem={({ item }) => (
          <View style={styles.bloco}>
            <Bloco bloco={item} />
          </View>
        )}
        ListHeaderComponent={topo}
        ListFooterComponent={
          documento ? (
            <Cartao style={styles.fim}>
              <Botao titulo="Voltar" variante="secundario" onPress={onVoltar} />
            </Cartao>
          ) : null
        }
        showsVerticalScrollIndicator={false}
        contentContainerStyle={estiloConteudoCentral}
      />
    </TelaBase>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  voltar: { alignSelf: 'flex-start', paddingHorizontal: 0, minHeight: 40 },
  titulo: { fontSize: fontes.titulo - 4, fontWeight: '800', color: cores.texto },
  versao: { fontSize: fontes.pequena + 1, color: cores.textoSuave, marginTop: espacos.xs, marginBottom: espacos.md },
  bloco: { paddingHorizontal: 2 },
  fim: { marginTop: espacos.lg },
});
