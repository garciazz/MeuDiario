import { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import TelaBase from '../components/TelaBase';
import ConteudoRolavel from '../components/ConteudoRolavel';
import LogoMarca from '../components/LogoMarca';
import Cartao from '../components/Cartao';
import Botao from '../components/Botao';
import Carregando from '../components/Carregando';
import MensagemFeedback from '../components/MensagemFeedback';
import CaixaMarcacao from '../components/CaixaMarcacao';
import AvisoConsentimento from '../components/AvisoConsentimento';
import useConsentimentoController from '../controllers/useConsentimentoController';
import { useAuth } from '../controllers/AuthContext';
import { espacos, fontes } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

// Tela mostrada antes do primeiro registro (e sempre que o Termo mudar de versão).
// O diário só é liberado depois do aceite explícito.
export default function ConsentimentoScreen({ onAbrirDocumento }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  const c = useConsentimentoController();
  const { usuario } = useAuth();
  const novaVersao = !!usuario?.consentimento?.versao; // já aceitou uma versão antiga

  return (
    <TelaBase edges={['top', 'bottom', 'left', 'right']}>
      <ConteudoRolavel>
        <LogoMarca compacta />
        {c.carregando ? <Carregando mensagem="Carregando o aviso..." /> : null}
        {!c.carregando && !c.termos ? (
          <Cartao>
            <MensagemFeedback texto={c.erro || 'Não foi possível carregar o aviso.'} />
            <Botao titulo="Tentar de novo" variante="secundario" onPress={c.tentarDeNovo} />
            <Botao titulo="Sair" variante="link" onPress={c.sair} />
          </Cartao>
        ) : null}

        {c.termos ? (
          <Cartao>
            {novaVersao ? (
              <MensagemFeedback
                tipo="info"
                texto="O Termo foi atualizado. Leia o aviso abaixo e autorize novamente para continuar."
              />
            ) : null}
            <AvisoConsentimento aviso={c.termos.aviso} onAbrirDocumento={onAbrirDocumento} />

            <View style={styles.aceite}>
              <CaixaMarcacao marcada={c.marcada} onAlternar={c.setMarcada} texto={c.termos.texto_aceite} />
            </View>

            <MensagemFeedback texto={c.erro} />
            {c.recusou ? (
              <MensagemFeedback
                tipo="info"
                texto="Tudo bem. Sem a sua autorização não é possível registrar no diário. Você pode ler o Termo com calma e voltar quando quiser, ou sair da conta."
              />
            ) : null}

            <View style={styles.botoes}>
              <Botao
                titulo="Concordo e continuar"
                onPress={c.concordar}
                desabilitado={!c.marcada}
                carregando={c.enviando}
              />
              <Botao titulo="Não concordo" variante="secundario" onPress={c.recusar} desabilitado={c.enviando} />
              {c.recusou ? <Botao titulo="Sair da conta" variante="link" onPress={c.sair} /> : null}
            </View>
            <Text style={styles.rodape}>
              Você pode retirar a autorização quando quiser, na aba Privacidade.
            </Text>
          </Cartao>
        ) : null}
      </ConteudoRolavel>
    </TelaBase>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  aceite: { marginTop: espacos.sm, marginBottom: espacos.md },
  botoes: { gap: espacos.sm },
  rodape: { marginTop: espacos.md, textAlign: 'center', color: cores.textoSuave, fontSize: fontes.pequena + 1 },
});
