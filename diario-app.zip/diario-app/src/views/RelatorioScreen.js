import { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import TelaBase from '../components/TelaBase';
import ConteudoRolavel from '../components/ConteudoRolavel';
import Cabecalho from '../components/Cabecalho';
import Cartao from '../components/Cartao';
import Botao from '../components/Botao';
import Carregando from '../components/Carregando';
import CartaoResumo from '../components/CartaoResumo';
import SeletorPeriodo from '../components/SeletorPeriodo';
import BarraDistribuicao from '../components/BarraDistribuicao';
import GraficoDias from '../components/GraficoDias';
import MensagemFeedback from '../components/MensagemFeedback';
import useRelatorioController from '../controllers/useRelatorioController';
import { espacos, fontes } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

export default function RelatorioScreen() {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  const c = useRelatorioController();
  const r = c.relatorio;

  function conteudo() {
    if (c.carregando) return <Carregando mensagem="Montando o seu relatório..." />;

    if (c.erro && !r) {
      return (
        <View>
          <MensagemFeedback texto={c.erro} />
          <Botao titulo="Tentar de novo" variante="secundario" onPress={c.tentarNovamente} />
        </View>
      );
    }

    if (!r || r.total === 0) {
      return (
        <Text style={styles.vazio}>
          Ainda não há entradas neste período. Registre como você se sente no Diário e volte aqui
          para ver seus padrões. 🌱
        </Text>
      );
    }

    return (
      <View>
        <MensagemFeedback texto={c.erro} />

        <View style={styles.resumo}>
          <CartaoResumo valor={r.total} legenda={r.total === 1 ? 'Entrada' : 'Entradas'} />
          <CartaoResumo
            valor={r.mediaHumor.toFixed(1).replace('.', ',')}
            destaque={r.humorMedio ? r.humorMedio.icone : undefined}
            legenda="Humor médio"
          />
          <CartaoResumo valor={r.sequencia} legenda={r.sequencia === 1 ? 'Dia seguido' : 'Dias seguidos'} />
        </View>

        <MensagemFeedback texto={c.mensagemApoio} tipo="info" />

        <Cartao>
          <Text style={styles.secao}>Como você se sentiu</Text>
          <Text style={styles.dica}>
            {r.diasComRegistro} de {r.dias} dias com registro
          </Text>
          {r.distribuicao.map((item) => (
            <BarraDistribuicao
              key={item.humor.id}
              humor={item.humor}
              quantidade={item.quantidade}
              percentual={item.percentual}
            />
          ))}
        </Cartao>

        <Cartao>
          <Text style={styles.secao}>Dia a dia</Text>
          <Text style={styles.dica}>Humor médio de cada dia. Quanto mais alta a barra, mais leve o dia.</Text>
          <GraficoDias serie={r.serie} />
        </Cartao>
      </View>
    );
  }

  return (
    <TelaBase>
      <ConteudoRolavel refreshing={c.atualizando} onRefresh={c.atualizar}>
        <Cabecalho titulo="Seu relatório" subtitulo="Seus padrões emocionais ao longo do tempo" />
        <SeletorPeriodo periodo={c.periodo} onMudar={c.setPeriodo} />
        <Botao
          titulo={c.gerandoPdf ? 'Gerando o PDF...' : `Gerar PDF (${c.periodo} dias)`}
          variante="secundario"
          onPress={c.gerarPdf}
          carregando={c.gerandoPdf}
          desabilitado={c.carregando || !r || r.total === 0}
          style={styles.botaoPdf}
        />
        <MensagemFeedback texto={c.erroPdf} />
        {conteudo()}
      </ConteudoRolavel>
    </TelaBase>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  botaoPdf: { marginBottom: espacos.md },
  resumo: { flexDirection: 'row', gap: espacos.sm, marginBottom: espacos.md },
  secao: { fontSize: fontes.subtitulo - 2, fontWeight: '800', color: cores.texto },
  dica: { fontSize: fontes.pequena, color: cores.textoSuave, marginBottom: espacos.md, marginTop: 2 },
  vazio: { textAlign: 'center', color: cores.textoSuave, fontSize: fontes.corpo, padding: espacos.lg, lineHeight: 22 },
});
