import { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import TelaBase from '../components/TelaBase';
import ConteudoRolavel from '../components/ConteudoRolavel';
import Cabecalho from '../components/Cabecalho';
import Cartao from '../components/Cartao';
import CampoTexto from '../components/CampoTexto';
import Botao from '../components/Botao';
import MensagemFeedback from '../components/MensagemFeedback';
import SeletorTema from '../components/SeletorTema';
import usePrivacidadeController from '../controllers/usePrivacidadeController';
import { espacos, fontes } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

function dataHora(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const dois = (n) => String(n).padStart(2, '0');
  return `${dois(d.getDate())}/${dois(d.getMonth() + 1)}/${d.getFullYear()} às ${dois(d.getHours())}:${dois(d.getMinutes())}`;
}

// Aba Privacidade: situação da autorização, leitura dos documentos e retirada da autorização.
export default function PrivacidadeScreen({ onAbrirDocumento }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  const c = usePrivacidadeController();
  const consentimento = c.consentimento;

  return (
    <TelaBase>
      <ConteudoRolavel>
        <Cabecalho titulo="Privacidade" subtitulo="Os seus dados, as suas regras." />

        <Cartao>
          <Text style={styles.secao}>Sua autorização</Text>
          {consentimento?.aceito_em ? (
            <Text style={styles.texto}>
              Você autorizou o uso dos seus dados pessoais sensíveis em {dataHora(consentimento.aceito_em)}
              {consentimento.versao ? ` (Termo versão ${consentimento.versao})` : ''}.
            </Text>
          ) : (
            <Text style={styles.texto}>Você ainda não autorizou o uso dos seus dados sensíveis.</Text>
          )}
          <Text style={styles.texto}>
            Seus dados ficam em servidor próprio da RG Systems e não são divulgados a terceiros.
          </Text>
          <View style={styles.botoes}>
            <Botao titulo="Ler o Termo completo" variante="secundario" onPress={() => onAbrirDocumento('termo')} />
            <Botao titulo="Ler a Política de Privacidade" variante="secundario" onPress={() => onAbrirDocumento('politica')} />
          </View>
        </Cartao>

        <Cartao>
          <Text style={styles.secao}>Aparência</Text>
          <Text style={styles.texto}>Escolha as cores do aplicativo. A escolha fica salva neste aparelho.</Text>
          <SeletorTema />
        </Cartao>

        <Cartao>
          <Text style={styles.secao}>Retirar a autorização</Text>
          <Text style={styles.texto}>
            Você pode retirar a autorização a qualquer momento. Para isso, excluímos a sua conta e todos os seus dados dos nossos
            servidores. Essa ação não pode ser desfeita.
          </Text>
          {c.confirmando ? (
            <View style={styles.confirmacao}>
              <MensagemFeedback
                tipo="info"
                texto="Tem certeza? Todas as suas entradas, áreas de interesse e a sua conta serão apagadas."
              />
              <CampoTexto
                rotulo="Digite a sua senha para confirmar"
                senha
                value={c.senha}
                onChangeText={c.setSenha}
                autoCapitalize="none"
                autoComplete="current-password"
                erro={c.erroSenha}
              />
              <MensagemFeedback texto={c.erro} />
              <View style={styles.botoes}>
                <Botao titulo="Apagar minha conta e meus dados" onPress={c.confirmar} carregando={c.excluindo} />
                <Botao titulo="Cancelar" variante="secundario" onPress={c.cancelar} desabilitado={c.excluindo} />
              </View>
            </View>
          ) : (
            <Botao titulo="Retirar autorização e apagar a conta" variante="secundario" onPress={c.iniciar} style={styles.gap} />
          )}
        </Cartao>
      </ConteudoRolavel>
    </TelaBase>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  secao: { fontSize: fontes.subtitulo - 2, fontWeight: '800', color: cores.texto, marginBottom: espacos.sm },
  texto: { fontSize: fontes.corpo, lineHeight: 23, color: cores.texto, marginBottom: espacos.sm },
  botoes: { gap: espacos.sm, marginTop: espacos.xs },
  confirmacao: { marginTop: espacos.sm },
  gap: { marginTop: espacos.sm },
});
