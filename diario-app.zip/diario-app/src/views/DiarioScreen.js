import { useMemo } from 'react';
import { ActivityIndicator, FlatList, StyleSheet, Text, View } from 'react-native';
import TelaBase from '../components/TelaBase';
import { estiloConteudoCentral } from '../components/ConteudoRolavel';
import Cabecalho from '../components/Cabecalho';
import Cartao from '../components/Cartao';
import CampoTexto from '../components/CampoTexto';
import Botao from '../components/Botao';
import Carregando from '../components/Carregando';
import SeletorHumor from '../components/SeletorHumor';
import EntradaItem from '../components/EntradaItem';
import MensagemFeedback from '../components/MensagemFeedback';
import useDiarioController from '../controllers/useDiarioController';
import { useAuth } from '../controllers/AuthContext';
import { espacos, fontes } from '../theme/tema';
import { useTema } from '../theme/TemaContext';
import { dataCompletaAmigavel, hojeISO } from '../utils/datas';

export default function DiarioScreen() {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  const c = useDiarioController();
  const { usuario, sair } = useAuth();
  const primeiroNome = (usuario?.nome || '').split(' ')[0];

  // O formulário fica no cabeçalho da lista: tudo rola junto com as entradas.
  const cabecalho = (
    <View>
      <Cabecalho
        titulo={primeiroNome ? `Olá, ${primeiroNome}` : 'Olá'}
        subtitulo={dataCompletaAmigavel(hojeISO())}
        acao={{ titulo: 'Sair', onPress: sair }}
      />

      <Cartao>
        <Text style={styles.pergunta}>Como você está se sentindo?</Text>
        <SeletorHumor
          humores={c.humores}
          selecionadoId={c.humorId}
          onSelecionar={c.setHumorId}
          carregando={c.carregandoHumores}
          erro={c.erroHumores}
          onTentarNovamente={c.recarregarHumores}
        />

        <View style={styles.campos}>
          <CampoTexto
            rotulo="O que te fez bem?"
            value={c.fezBem}
            onChangeText={c.setFezBem}
            placeholder="Um momento, uma pessoa, uma conquista..."
            multiline
          />
          <CampoTexto
            rotulo="O que te fez mal?"
            value={c.fezMal}
            onChangeText={c.setFezMal}
            placeholder="O que pesou no seu dia?"
            multiline
          />
          <CampoTexto
            rotulo="O que você aprendeu hoje?"
            value={c.aprendeu}
            onChangeText={c.setAprendeu}
            placeholder="Algo novo sobre você ou sobre a vida"
            multiline
          />
        </View>

        <MensagemFeedback texto={c.erroForm} />
        <MensagemFeedback texto={c.mensagemSucesso} tipo="sucesso" />
        <Botao titulo="Salvar no meu diário" onPress={c.salvar} carregando={c.salvando} />
      </Cartao>

      <Text style={styles.secao}>Suas entradas</Text>
      <MensagemFeedback texto={c.erroLista} />
    </View>
  );

  return (
    <TelaBase>
      <FlatList
        data={c.entradas}
        keyExtractor={(entrada) => String(entrada.id)}
        renderItem={({ item }) => <EntradaItem entrada={item} />}
        ListHeaderComponent={cabecalho}
        ListEmptyComponent={
          c.carregandoLista ? (
            <Carregando mensagem="Abrindo seu diário..." />
          ) : (
            <Text style={styles.vazio}>
              Você ainda não registrou nenhuma entrada. Que tal começar agora? 🌱
            </Text>
          )
        }
        ListFooterComponent={c.carregandoMais ? <ActivityIndicator color={cores.primaria} /> : null}
        onEndReached={c.carregarMais}
        onEndReachedThreshold={0.4}
        refreshing={c.atualizando}
        onRefresh={c.atualizar}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={estiloConteudoCentral}
      />
    </TelaBase>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  pergunta: { fontSize: fontes.subtitulo - 2, fontWeight: '800', color: cores.texto, marginBottom: espacos.sm },
  campos: { marginTop: espacos.md },
  secao: { fontSize: fontes.subtitulo, fontWeight: '800', color: cores.texto, marginBottom: espacos.sm },
  vazio: { textAlign: 'center', color: cores.textoSuave, fontSize: fontes.corpo, padding: espacos.lg, lineHeight: 22 },
});
