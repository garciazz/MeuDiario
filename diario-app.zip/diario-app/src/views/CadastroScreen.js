import { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import TelaBase from '../components/TelaBase';
import ConteudoRolavel from '../components/ConteudoRolavel';
import LogoMarca from '../components/LogoMarca';
import Cartao from '../components/Cartao';
import CampoTexto from '../components/CampoTexto';
import Botao from '../components/Botao';
import Carregando from '../components/Carregando';
import ChipSelecionavel from '../components/ChipSelecionavel';
import MensagemFeedback from '../components/MensagemFeedback';
import CaixaMarcacao from '../components/CaixaMarcacao';
import AvisoConsentimento from '../components/AvisoConsentimento';
import useCadastroController from '../controllers/useCadastroController';
import { espacos, fontes } from '../theme/tema';
import { useTema } from '../theme/TemaContext';

export default function CadastroScreen({ onVoltar, onAbrirDocumento }) {
  const { cores } = useTema();
  const styles = useMemo(() => criarEstilos(cores), [cores]);
  const c = useCadastroController();

  return (
    <TelaBase edges={['top', 'bottom', 'left', 'right']}>
      <ConteudoRolavel>
        <LogoMarca compacta />
        <Cartao>
          <Text style={styles.titulo}>Criar minha conta</Text>
          <Text style={styles.subtitulo}>Leva menos de um minuto.</Text>

          <MensagemFeedback texto={c.erroGeral} />

          <CampoTexto
            rotulo="Nome"
            value={c.nome}
            onChangeText={c.setNome}
            placeholder="Como podemos te chamar?"
            autoCapitalize="words"
            autoComplete="name"
            erro={c.erros.nome}
          />
          <CampoTexto
            rotulo="E-mail"
            value={c.email}
            onChangeText={c.setEmail}
            placeholder="voce@exemplo.com"
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            autoComplete="email"
            erro={c.erros.email}
          />
          <CampoTexto
            rotulo="Senha"
            senha
            value={c.senha}
            onChangeText={c.setSenha}
            placeholder="Pelo menos 8 caracteres"
            autoCapitalize="none"
            autoComplete="new-password"
            erro={c.erros.senha}
          />
          <CampoTexto
            rotulo="Confirmar senha"
            senha
            value={c.confirmarSenha}
            onChangeText={c.setConfirmarSenha}
            placeholder="Repita a senha"
            autoCapitalize="none"
            autoComplete="new-password"
            erro={c.erros.confirmarSenha}
          />
          <CampoTexto
            rotulo="Data de nascimento (opcional)"
            value={c.dataNascimento}
            onChangeText={c.setDataNascimento}
            placeholder="DD/MM/AAAA"
            keyboardType="number-pad"
            maxLength={10}
            erro={c.erros.dataNascimento}
          />

          <View style={styles.aviso}>
            {c.carregandoTermos ? <Carregando mensagem="Carregando o aviso..." /> : null}
            {c.erroTermos ? (
              <View>
                <MensagemFeedback texto={c.erroTermos} tipo="info" />
                <Botao titulo="Tentar de novo" variante="secundario" onPress={c.tentarTermosDeNovo} />
              </View>
            ) : null}
            {c.termos ? (
              <View>
                <AvisoConsentimento aviso={c.termos.aviso} onAbrirDocumento={onAbrirDocumento} />
                <CaixaMarcacao
                  marcada={c.autorizou}
                  onAlternar={c.setAutorizou}
                  texto={c.termos.texto_aceite}
                  erro={c.erros.consentimento}
                />
              </View>
            ) : null}
          </View>

          <Text style={styles.secao}>Quais temas fazem parte da sua jornada?</Text>
          <Text style={styles.dica}>
            {c.autorizou
              ? 'Opcional. Você pode escolher quantos quiser.'
              : 'Para escolher temas, marque a autorização acima. Sem ela, você ainda pode criar a conta, mas o diário só será liberado depois do seu aceite.'}
          </Text>
          {c.carregandoAreas ? <Carregando /> : null}
          {c.erroAreas ? <MensagemFeedback texto={c.erroAreas} tipo="info" /> : null}
          {c.erros.areas ? <MensagemFeedback texto={c.erros.areas} /> : null}
          <View style={styles.chips}>
            {c.areas.map((area) => (
              <ChipSelecionavel
                key={area.id}
                titulo={area.nome}
                selecionado={c.areasSelecionadas.includes(area.id)}
                desabilitado={!c.autorizou}
                onPress={() => c.alternarArea(area.id)}
              />
            ))}
          </View>

          <Botao titulo="Criar conta" onPress={c.enviar} carregando={c.enviando} />
        </Cartao>

        <View style={styles.rodape}>
          <Text style={styles.rodapeTexto}>Já tem uma conta?</Text>
          <Botao titulo="Voltar para o login" variante="secundario" onPress={onVoltar} />
        </View>
      </ConteudoRolavel>
    </TelaBase>
  );
}

const criarEstilos = (cores) => StyleSheet.create({
  titulo: { fontSize: fontes.subtitulo, fontWeight: '800', color: cores.texto },
  subtitulo: { fontSize: fontes.corpo, color: cores.textoSuave, marginTop: 4, marginBottom: espacos.md },
  aviso: { backgroundColor: cores.fundo, borderRadius: 16, borderWidth: 1, borderColor: cores.borda, padding: espacos.md, marginTop: espacos.sm, marginBottom: espacos.sm },
  secao: { fontSize: fontes.corpo, fontWeight: '700', color: cores.texto, marginTop: espacos.sm },
  dica: { fontSize: fontes.pequena, color: cores.textoSuave, marginBottom: espacos.sm },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: espacos.sm, marginBottom: espacos.lg },
  rodape: { marginTop: espacos.sm, gap: espacos.sm },
  rodapeTexto: { textAlign: 'center', color: cores.textoSuave, fontSize: fontes.corpo },
});
