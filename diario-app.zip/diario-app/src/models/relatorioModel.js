import { hojeISO, somarDias, ultimosDias } from '../utils/datas';

// Regras de negócio do relatório: funções puras, sem acesso à API nem à tela.

export const PERIODOS = [
  { dias: 7, rotulo: '7 dias' },
  { dias: 30, rotulo: '30 dias' },
  { dias: 90, rotulo: '90 dias' },
];

function media(valores) {
  return valores.length ? valores.reduce((soma, v) => soma + v, 0) / valores.length : null;
}

// O humor do catálogo cujo valor (1 a 5) é o mais próximo da média.
export function humorMaisProximo(humores, valor) {
  if (valor === null || valor === undefined || !humores.length) return null;
  return humores.reduce((melhor, atual) =>
    Math.abs(atual.valor - valor) < Math.abs(melhor.valor - valor) ? atual : melhor
  );
}

// Dias seguidos com registro. Se hoje ainda não tem entrada, a sequência continua valendo desde ontem.
export function calcularSequencia(entradas, hoje = hojeISO()) {
  const datas = new Set(entradas.map((e) => e.data_entrada));
  let cursor = datas.has(hoje) ? hoje : somarDias(hoje, -1);
  let total = 0;
  while (datas.has(cursor)) {
    total += 1;
    cursor = somarDias(cursor, -1);
  }
  return total;
}

// Monta tudo o que a tela Relatório mostra para os últimos "dias" dias.
export function calcularRelatorio(entradas, humores, dias, hoje = hojeISO()) {
  const listaDeDias = ultimosDias(dias, hoje);
  const inicio = listaDeDias[0];
  const doPeriodo = entradas.filter((e) => e.data_entrada >= inicio && e.data_entrada <= hoje);
  const total = doPeriodo.length;
  const mediaHumor = media(doPeriodo.map((e) => e.humor.valor));

  const distribuicao = humores.map((humor) => {
    const quantidade = doPeriodo.filter((e) => e.humor.id === humor.id).length;
    return {
      humor,
      quantidade,
      percentual: total ? Math.round((quantidade * 100) / total) : 0,
    };
  });

  const valoresPorDia = new Map();
  doPeriodo.forEach((e) => {
    const valores = valoresPorDia.get(e.data_entrada) || [];
    valores.push(e.humor.valor);
    valoresPorDia.set(e.data_entrada, valores);
  });

  const serie = listaDeDias.map((data) => {
    const valores = valoresPorDia.get(data);
    const mediaDoDia = valores ? media(valores) : null;
    return {
      data,
      media: mediaDoDia,
      humor: humorMaisProximo(humores, mediaDoDia),
      quantidade: valores ? valores.length : 0,
    };
  });

  return {
    dias,
    total,
    mediaHumor,
    humorMedio: humorMaisProximo(humores, mediaHumor),
    distribuicao,
    serie,
    diasComRegistro: serie.filter((d) => d.quantidade > 0).length,
    sequencia: calcularSequencia(entradas, hoje),
  };
}

// Mensagem de acolhimento conforme a média de humor do período (escala de 1 a 5).
export function mensagemDeApoio(mediaHumor) {
  if (mediaHumor === null || mediaHumor === undefined) return '';
  if (mediaHumor < 2.5) {
    return 'Parece que esses dias foram pesados. Seja gentil com você e, se precisar, converse com alguém de confiança ou com um profissional de saúde.';
  }
  if (mediaHumor < 3.5) {
    return 'Dias de altos e baixos fazem parte. Continue registrando para perceber o que ajuda você a se sentir melhor.';
  }
  return 'Que bom ver tantos dias leves! Que tal anotar o que tem ajudado para repetir nos dias difíceis?';
}
