import { requisitar } from './http';

export async function listarHumores() {
  const { humores } = await requisitar('GET', '/humores', { autenticado: false });
  return humores;
}

export async function listarAreasInteresse() {
  const { areas_interesse: areas } = await requisitar('GET', '/areas-interesse', {
    autenticado: false,
  });
  return areas;
}
