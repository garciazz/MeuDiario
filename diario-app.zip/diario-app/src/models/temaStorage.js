import { Platform } from 'react-native';
import * as SecureStore from 'expo-secure-store';

// Guarda o tema de cores escolhido neste aparelho (não é dado pessoal sensível).
const CHAVE = 'diario.tema';

export async function lerTema() {
  try {
    return Platform.OS === 'web' ? window.localStorage.getItem(CHAVE) : await SecureStore.getItemAsync(CHAVE);
  } catch {
    return null;
  }
}

export async function salvarTema(id) {
  try {
    if (Platform.OS === 'web') window.localStorage.setItem(CHAVE, id);
    else await SecureStore.setItemAsync(CHAVE, id);
  } catch {
    // sem armazenamento: o tema vale só até fechar o app
  }
}
