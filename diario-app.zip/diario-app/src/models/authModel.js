import { requisitar } from './http';
import * as sessaoStorage from './sessaoStorage';

export async function login(email, senha) {
  const dados = await requisitar('POST', '/auth/login', {
    corpo: { email, senha },
    autenticado: false,
  });
  await sessaoStorage.salvar(dados);
  return dados.usuario;
}

// consentimento: { versao, aceito: true } quando a pessoa marcou a autorização no cadastro.
export async function cadastrar({ nome, email, senha, dataNascimento, areas, consentimento }) {
  const dados = await requisitar('POST', '/usuarios', {
    corpo: {
      nome,
      email,
      senha,
      data_nascimento: dataNascimento || undefined,
      areas_interesse: areas,
      consentimento,
    },
    autenticado: false,
  });
  await sessaoStorage.salvar(dados);
  return dados.usuario;
}

// Ao abrir o app: se há tokens guardados, confere com a API se a sessão ainda vale.
export async function restaurarSessao() {
  const [accessToken, refreshToken] = await Promise.all([
    sessaoStorage.lerAccessToken(),
    sessaoStorage.lerRefreshToken(),
  ]);
  if (!accessToken && !refreshToken) return null;

  try {
    const { usuario } = await requisitar('GET', '/auth/me');
    return usuario;
  } catch (erro) {
    if (erro.status === 401) await sessaoStorage.limpar();
    return null;
  }
}

// Sempre limpa a sessão local, mesmo que a API não responda.
export async function logout() {
  try {
    const refreshToken = await sessaoStorage.lerRefreshToken();
    await requisitar('POST', '/auth/logout', { corpo: { refreshToken } });
  } catch {
    // sem conexão ou token já inválido: segue com a saída local
  } finally {
    await sessaoStorage.limpar();
  }
}

// Retirar a autorização = excluir a conta e todos os dados (exige a senha). Limpa a sessão local.
export async function excluirConta(senha) {
  await requisitar('DELETE', '/usuarios/me', { corpo: { senha } });
  await sessaoStorage.limpar();
}
