import { API_URL, TEMPO_LIMITE_MS } from '../config/env';
import * as sessaoStorage from './sessaoStorage';

// Erro padrão da camada de dados: status HTTP (0 = sem conexão), mensagem em português
// e, quando a API envia, os erros por campo em "detalhes".
export class ApiError extends Error {
  constructor(status, mensagem, detalhes, codigo) {
    super(mensagem);
    this.codigo = codigo; // ex.: CONSENTIMENTO_NECESSARIO
    this.name = 'ApiError';
    this.status = status;
    this.detalhes = detalhes;
  }
}

// O AuthContext registra aqui o que fazer quando a sessão não pode mais ser renovada.
let aoExpirarSessao = () => {};
export function definirAoExpirarSessao(funcao) {
  aoExpirarSessao = funcao;
}

export function montarQuery(params = {}) {
  const partes = Object.entries(params)
    .filter(([, valor]) => valor !== undefined && valor !== null && valor !== '')
    .map(([chave, valor]) => `${encodeURIComponent(chave)}=${encodeURIComponent(valor)}`);
  return partes.length ? `?${partes.join('&')}` : '';
}

async function chamar(metodo, caminho, corpo, accessToken) {
  const controle = new AbortController();
  const cronometro = setTimeout(() => controle.abort(), TEMPO_LIMITE_MS);
  try {
    const resposta = await fetch(`${API_URL}${caminho}`, {
      method: metodo,
      headers: {
        'Content-Type': 'application/json',
        ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
      },
      body: corpo ? JSON.stringify(corpo) : undefined,
      signal: controle.signal,
    });

    let dados = null;
    if (resposta.status !== 204) {
      try {
        dados = await resposta.json();
      } catch {
        dados = null;
      }
    }
    if (!resposta.ok) {
      throw new ApiError(
        resposta.status,
        dados?.erro?.mensagem || 'Algo deu errado. Tente novamente.',
        dados?.erro?.detalhes,
        dados?.erro?.codigo
      );
    }
    return dados;
  } catch (erro) {
    if (erro instanceof ApiError) throw erro;
    throw new ApiError(
      0,
      erro.name === 'AbortError'
        ? 'O servidor demorou demais para responder. Tente novamente.'
        : 'Não foi possível conectar ao servidor. Verifique sua internet.'
    );
  } finally {
    clearTimeout(cronometro);
  }
}

// Várias chamadas podem receber 401 ao mesmo tempo: todas esperam a mesma renovação,
// já que cada refresh token só pode ser usado uma vez.
let renovacaoEmAndamento = null;

function renovarTokens() {
  if (!renovacaoEmAndamento) {
    renovacaoEmAndamento = (async () => {
      const refreshToken = await sessaoStorage.lerRefreshToken();
      if (!refreshToken) throw new ApiError(401, 'Sessão expirada. Entre novamente.');
      const novos = await chamar('POST', '/auth/refresh', { refreshToken });
      await sessaoStorage.salvar(novos);
      return novos.accessToken;
    })().finally(() => {
      renovacaoEmAndamento = null;
    });
  }
  return renovacaoEmAndamento;
}

// Ponto único de acesso à API. Rotas protegidas recebem o token automaticamente e,
// se ele tiver expirado, é feita uma renovação e a chamada é repetida uma vez.
export async function requisitar(metodo, caminho, { corpo, autenticado = true } = {}) {
  if (!autenticado) return chamar(metodo, caminho, corpo);

  const accessToken = await sessaoStorage.lerAccessToken();
  try {
    return await chamar(metodo, caminho, corpo, accessToken);
  } catch (erro) {
    if (erro.status !== 401) throw erro;

    let novoToken;
    try {
      novoToken = await renovarTokens();
    } catch (erroRenovacao) {
      if (erroRenovacao.status === 0) throw erroRenovacao; // sem internet: mantém a sessão
      await sessaoStorage.limpar();
      aoExpirarSessao();
      throw erro;
    }
    return chamar(metodo, caminho, corpo, novoToken);
  }
}
