import { requisitar } from './http';

let guardado = null;

// Aviso, Termo e Política na versão vigente (texto vem da API, que também guarda a versão aceita).
// Fica em memória depois da primeira busca; "forcar" busca de novo.
export async function buscarTermos({ forcar = false } = {}) {
  if (!guardado || forcar) guardado = await requisitar('GET', '/termos/atual', { autenticado: false });
  return guardado;
}

// Registra o aceite da versão informada. Devolve a situação: { vigente, versao, aceito_em, versao_vigente }.
export async function aceitar(versao) {
  const { consentimento } = await requisitar('POST', '/consentimentos', {
    corpo: { versao, aceito: true },
  });
  return consentimento;
}
