import { requisitar, montarQuery } from './http';

// Uma página de entradas do usuário logado, da mais recente para a mais antiga.
export async function listar({ de, ate, humorId, limite = 20, offset = 0 } = {}) {
  const query = montarQuery({ de, ate, humor_id: humorId, limite, offset });
  return requisitar('GET', `/entradas${query}`); // { entradas, paginacao: { total, limite, offset } }
}

// Registra uma entrada. As 3 perguntas do diário viram o texto da entrada na API.
export async function criar({ humorId, fezBem, fezMal, aprendeu, dataEntrada }) {
  const { entrada } = await requisitar('POST', '/entradas', {
    corpo: {
      humor_id: humorId,
      fez_bem: fezBem || undefined,
      fez_mal: fezMal || undefined,
      aprendeu: aprendeu || undefined,
      data_entrada: dataEntrada,
    },
  });
  return entrada;
}

// Busca todas as entradas de um período, percorrendo as páginas da API (até 1000 entradas).
export async function listarDoPeriodo(de, ate) {
  const todas = [];
  let offset = 0;
  for (let pagina = 0; pagina < 10; pagina += 1) {
    const { entradas, paginacao } = await listar({ de, ate, limite: 100, offset });
    todas.push(...entradas);
    offset += entradas.length;
    if (!entradas.length || offset >= paginacao.total) break;
  }
  return todas;
}
