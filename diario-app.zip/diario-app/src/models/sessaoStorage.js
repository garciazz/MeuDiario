import { Platform } from 'react-native';
import * as SecureStore from 'expo-secure-store';

// Guarda os tokens da sessão. No celular usa o armazenamento seguro do sistema
// (Keychain/Keystore); no navegador, onde isso não existe, usa o localStorage.

const CHAVE_ACCESS = 'diario.accessToken';
const CHAVE_REFRESH = 'diario.refreshToken';

const armazenamento =
  Platform.OS === 'web'
    ? {
        async ler(chave) {
          try {
            return window.localStorage.getItem(chave);
          } catch {
            return null;
          }
        },
        async gravar(chave, valor) {
          try {
            window.localStorage.setItem(chave, valor);
          } catch {
            // armazenamento indisponível (ex.: modo privado): a sessão só dura até fechar a página
          }
        },
        async apagar(chave) {
          try {
            window.localStorage.removeItem(chave);
          } catch {
            // ignora
          }
        },
      }
    : {
        ler: (chave) => SecureStore.getItemAsync(chave),
        gravar: (chave, valor) => SecureStore.setItemAsync(chave, valor),
        apagar: (chave) => SecureStore.deleteItemAsync(chave),
      };

export async function salvar({ accessToken, refreshToken }) {
  await armazenamento.gravar(CHAVE_ACCESS, accessToken);
  await armazenamento.gravar(CHAVE_REFRESH, refreshToken);
}

export const lerAccessToken = () => armazenamento.ler(CHAVE_ACCESS);
export const lerRefreshToken = () => armazenamento.ler(CHAVE_REFRESH);

export async function limpar() {
  await armazenamento.apagar(CHAVE_ACCESS);
  await armazenamento.apagar(CHAVE_REFRESH);
}
