import { Platform } from 'react-native';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import * as IntentLauncher from 'expo-intent-launcher';
import * as FileSystem from 'expo-file-system/legacy';

const ANDROID_FLAG_LER_URI = 1; // FLAG_GRANT_READ_URI_PERMISSION

// Grava o PDF numa pasta do próprio app, com nome legível. O expo-print devolve o PDF em base64 e em um
// caminho temporário que o expo-sharing e o expo-file-system podem recusar ("Not allowed to read file
// under given URL" / "Missing READ permission"). Gravando nós mesmos, o caminho é sempre um que o app lê.
async function gravarPdf(base64, nomeArquivo) {
  const destino = `${FileSystem.cacheDirectory}${nomeArquivo}`;
  await FileSystem.writeAsStringAsync(destino, base64, { encoding: FileSystem.EncodingType.Base64 });
  return destino;
}

async function compartilhar(uri) {
  await Sharing.shareAsync(uri, {
    mimeType: 'application/pdf',
    UTI: 'com.adobe.pdf',
    dialogTitle: 'Relatório do Meu Diário',
  });
}

async function abrirNoAndroid(uri) {
  try {
    // Abre direto no leitor de PDF do aparelho (precisa de um content:// URI para outro app ler o arquivo).
    const contentUri = await FileSystem.getContentUriAsync(uri);
    await IntentLauncher.startActivityAsync('android.intent.action.VIEW', {
      data: contentUri,
      type: 'application/pdf',
      flags: ANDROID_FLAG_LER_URI,
    });
  } catch {
    // Sem leitor de PDF instalado (ou falha ao abrir): oferece a folha de compartilhamento.
    await compartilhar(uri);
  }
}

// Gera o PDF a partir do HTML e abre para a pessoa.
//  - Android: cria o arquivo e abre no leitor de PDF.
//  - iOS: cria o arquivo e abre a folha de compartilhamento (Visualizar, Arquivos, Livros, AirDrop...).
//  - Web (só para testes no navegador): abre a janela de impressão, onde se escolhe "Salvar como PDF".
// Importante: na web, a janela precisa ser aberta direto no toque do botão (antes de qualquer "await").
export async function gerarEAbrirPdf({ html, nomeArquivo }) {
  if (Platform.OS === 'web') {
    const janela = window.open('', '_blank');
    if (!janela) throw new Error('O navegador bloqueou a janela do PDF. Permita pop-ups para este site e tente de novo.');
    janela.document.open();
    janela.document.write(html);
    janela.document.close();
    janela.document.title = nomeArquivo;
    janela.focus();
    setTimeout(() => janela.print(), 400);
    return { aberto: 'impressao' };
  }

  const { base64 } = await Print.printToFileAsync({ html, base64: true });
  if (!base64) throw new Error('Não foi possível gerar o PDF. Tente novamente.');
  const caminho = await gravarPdf(base64, nomeArquivo);

  if (Platform.OS === 'android') {
    await abrirNoAndroid(caminho);
  } else {
    if (!(await Sharing.isAvailableAsync())) {
      throw new Error('Este aparelho não consegue abrir o PDF. O arquivo foi gerado, mas não há como mostrá-lo.');
    }
    await compartilhar(caminho);
  }
  return { aberto: 'arquivo', uri: caminho };
}
