import { useEffect, useState } from 'react';
import { BackHandler, StyleSheet, View } from 'react-native';
import { useAuth } from '../controllers/AuthContext';
import Carregando from '../components/Carregando';
import BarraAbas from '../components/BarraAbas';
import LoginScreen from '../views/LoginScreen';
import CadastroScreen from '../views/CadastroScreen';
import DiarioScreen from '../views/DiarioScreen';
import RelatorioScreen from '../views/RelatorioScreen';
import PrivacidadeScreen from '../views/PrivacidadeScreen';
import ConsentimentoScreen from '../views/ConsentimentoScreen';
import DocumentoScreen from '../views/DocumentoScreen';

// Navegação simples por estado: sem biblioteca extra.
//  - Sem login: Login <-> Cadastro
//  - Com login, sem aceite do Termo: tela de consentimento (bloqueia o diário)
//  - Com login e aceite: abas Diário | Relatório | Privacidade
//  - Termo e Política abrem por cima de qualquer tela e voltam para onde estavam
export default function AppNavigator() {
  const { usuario, carregandoSessao } = useAuth();
  const [telaPublica, setTelaPublica] = useState('login');
  const [aba, setAba] = useState('diario');
  const [documento, setDocumento] = useState(null); // 'termo' | 'politica' | null

  // Ao sair da conta, a próxima pessoa começa no login e na aba do Diário.
  useEffect(() => {
    if (!usuario) {
      setTelaPublica('login');
      setAba('diario');
    }
  }, [usuario]);

  // Botão "voltar" do Android: fecha o documento aberto ou, no cadastro, leva ao login.
  useEffect(() => {
    if (!documento && (usuario || telaPublica !== 'cadastro')) return undefined;
    const inscricao = BackHandler.addEventListener('hardwareBackPress', () => {
      if (documento) setDocumento(null);
      else setTelaPublica('login');
      return true;
    });
    return () => inscricao.remove();
  }, [usuario, telaPublica, documento]);

  if (carregandoSessao) return <Carregando tela mensagem="Abrindo o seu diário..." />;

  // Qualquer tela pode abrir o Termo ou a Política. As telas por baixo continuam montadas (só escondidas),
  // para ninguém perder o que já digitou no cadastro ou no diário.
  const abrirDocumento = (qual) => setDocumento(qual);
  const sobreposicao = documento ? (
    <View style={styles.sobreposicao}>
      <DocumentoScreen qual={documento} onVoltar={() => setDocumento(null)} />
    </View>
  ) : null;
  const esconder = documento ? styles.escondida : null;

  if (!usuario) {
    return (
      <View style={styles.raiz}>
        <View style={[styles.aba, esconder]}>
          {telaPublica === 'cadastro' ? (
            <CadastroScreen onVoltar={() => setTelaPublica('login')} onAbrirDocumento={abrirDocumento} />
          ) : (
            <LoginScreen onIrParaCadastro={() => setTelaPublica('cadastro')} onAbrirDocumento={abrirDocumento} />
          )}
        </View>
        {sobreposicao}
      </View>
    );
  }

  // Sem aceite da versão vigente do Termo, o diário fica bloqueado.
  if (!usuario.consentimento?.vigente) {
    return (
      <View style={styles.raiz}>
        <View style={[styles.aba, esconder]}>
          <ConsentimentoScreen onAbrirDocumento={abrirDocumento} />
        </View>
        {sobreposicao}
      </View>
    );
  }

  return (
    <View style={styles.raiz}>
      {sobreposicao}
      <View style={[styles.aba, esconder]}>
        {/* O Diário continua montado (só escondido) para não perder o que está sendo escrito. */}
        <View style={[styles.aba, aba !== 'diario' && styles.escondida]}>
          <DiarioScreen />
        </View>
        {/* Relatório e Privacidade são recriados a cada abertura, para sempre mostrar dados atualizados. */}
        {aba === 'relatorio' ? (
          <View style={styles.aba}>
            <RelatorioScreen />
          </View>
        ) : null}
        {aba === 'privacidade' ? (
          <View style={styles.aba}>
            <PrivacidadeScreen onAbrirDocumento={abrirDocumento} />
          </View>
        ) : null}
        <BarraAbas abaAtiva={aba} onMudar={setAba} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  raiz: { flex: 1 },
  aba: { flex: 1 },
  sobreposicao: { flex: 1 },
  escondida: { display: 'none' },
});
