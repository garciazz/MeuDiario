import { Platform } from 'react-native';

// O emulador Android enxerga o computador pelo IP especial 10.0.2.2.
// Simulador iOS e navegador (web) usam localhost.
// Em celular físico, defina EXPO_PUBLIC_API_URL com o IP do seu computador,
// por exemplo: EXPO_PUBLIC_API_URL=http://192.168.0.10:3000/api (veja o arquivo .env.example).
const HOST_PADRAO = Platform.select({ android: '10.0.2.2', default: 'localhost' });

export const API_URL = process.env.EXPO_PUBLIC_API_URL || `http://${HOST_PADRAO}:3000/api`;
export const TEMPO_LIMITE_MS = 15000;
