import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider } from './src/controllers/AuthContext';
import { TemaProvider, useTema } from './src/theme/TemaContext';
import AppNavigator from './src/navigation/AppNavigator';

// Ícones da barra de status claros nos temas escuros e escuros nos claros.
function BarraDeStatus() {
  const { tema } = useTema();
  return <StatusBar style={tema.escuro ? 'light' : 'dark'} />;
}

export default function App() {
  return (
    <SafeAreaProvider>
      <TemaProvider>
        <AuthProvider>
          <BarraDeStatus />
          <AppNavigator />
        </AuthProvider>
      </TemaProvider>
    </SafeAreaProvider>
  );
}
