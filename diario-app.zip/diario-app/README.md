# Meu Diário (app)

Aplicativo de diário emocional em React Native com Expo (SDK 58), organizado em camadas MVC e conectado à API `diario-api`.

Telas: **Login**, **Cadastro de novo usuário**, **Consentimento (aviso do Termo)**, **Termo e Política de Privacidade**, **Diário de Emoções**, **Relatório** (com botão **Gerar PDF**) e **Privacidade**.

## Como rodar

1. Deixe a API `diario-api` rodando (`npm run dev` na pasta dela, porta 3000).
2. Neste projeto:
   ```bash
   npm install
   npx expo start
   ```
3. No terminal do Expo, abra com:
   - `a` para o emulador Android;
   - `i` para o simulador iOS (somente no Mac);
   - `w` para o navegador;
   - ou escaneie o QR code com o app **Expo Go** (mantenha-o atualizado para o SDK 58).

### Endereço da API

O app escolhe sozinho o endereço (`src/config/env.js`):

| Onde roda | Endereço usado |
|---|---|
| Emulador Android | `http://10.0.2.2:3000/api` |
| Simulador iOS e navegador | `http://localhost:3000/api` |
| **Celular físico (Expo Go)** | defina o IP do seu computador, veja abaixo |

Em celular físico, copie `.env.example` para `.env`, troque o IP pelo do computador que roda a API (celular e computador na mesma rede Wi-Fi) e reinicie com `npx expo start -c`:

```
EXPO_PUBLIC_API_URL=http://192.168.0.10:3000/api
```

Se a API tiver `CORS_ORIGIN` configurado, inclua a origem do app web. Apps nativos não são afetados por CORS. Em uma versão publicada do app, a API precisa estar em HTTPS.

## Estrutura (MVC + componentes)

```
App.js                          SafeAreaProvider + AuthProvider + navegação
src/
  models/                       MODEL: dados e regras
    http.js                       cliente da API (token automático, renovação, erros)
    sessaoStorage.js              guarda os tokens (SecureStore no celular, localStorage na web)
    authModel.js                  login, cadastro, restaurar sessão, logout
    entradaModel.js               listar e criar entradas
    catalogoModel.js              humores e áreas de interesse
    relatorioModel.js             cálculos do relatório (médias, distribuição, sequência)
    termosModel.js                busca o aviso/Termo/Política na API e registra o aceite
    pdfModel.js                   gera o PDF (expo-print) e abre no aparelho
  controllers/                  CONTROLLER: estado e ações de cada tela (hooks)
    AuthContext.js                quem está logado (entrar, cadastrar, sair)
    useLoginController.js
    useCadastroController.js
    useDiarioController.js
    useRelatorioController.js     (inclui gerarPdf)
    useTermos.js  useConsentimentoController.js  usePrivacidadeController.js
  views/                        VIEW: as 4 telas (só desenham e chamam o controller)
    LoginScreen.js  CadastroScreen.js  DiarioScreen.js  RelatorioScreen.js
    ConsentimentoScreen.js  DocumentoScreen.js  PrivacidadeScreen.js
  components/                   peças reutilizáveis
    TelaBase, ConteudoRolavel, Cabecalho, LogoMarca, Cartao, Botao, CampoTexto,
    MensagemFeedback, Carregando, ChipSelecionavel, SeletorHumor, EntradaItem,
    SeletorPeriodo, CartaoResumo, BarraDistribuicao, GraficoDias, BarraAbas,
    CaixaMarcacao, AvisoConsentimento, BlocosDeTexto, SeletorTema
  navigation/AppNavigator.js    troca de telas por estado (sem biblioteca extra)
  theme/tema.js                 temas de cores, espaços, fontes e sombras
  theme/TemaContext.js          tema escolhido (useTema)
  config/env.js                 endereço da API por plataforma
  utils/datas.js                datas no formato AAAA-MM-DD, máscara DD/MM/AAAA
  utils/relatorioPdf.js         monta o HTML do relatório em PDF (função pura)
```

Fluxo: **View** mostra a tela e chama o **Controller** (hook), que guarda o estado e chama o **Model**, o único que fala com a API.

## Recursos usados

`useState`, `useEffect`, `ActivityIndicator`, `FlatList`, `Platform`, `StyleSheet`, `Text`, `View`, `SafeAreaProvider` e `SafeAreaView` (de `react-native-safe-area-context`), além de `TextInput`, `Pressable` e `KeyboardAvoidingView` para formulários e botões. Bibliotecas extras: `expo-secure-store` (guardar os tokens com segurança) e, para rodar no navegador, `react-native-web` e `react-dom`.

- `Platform` é usado no endereço da API, no armazenamento da sessão (celular x web), nas sombras e no teclado do iOS.
- Telas com rolagem usam `FlatList` (o formulário fica no cabeçalho da lista).

## Como funciona a sessão

- No login ou cadastro a API devolve `accessToken` (15 min) e `refreshToken` (7 dias), guardados no armazenamento seguro do aparelho.
- Toda chamada protegida envia o `accessToken`. Se a API responder `401`, o app renova o par de tokens automaticamente e repete a chamada; se não der, volta para o login.
- Ao abrir o app, a sessão salva é restaurada sem pedir a senha de novo. "Sair" encerra a sessão também na API.

## Telas

- **Login:** e-mail e senha (com mostrar/ocultar), mensagens de erro da API.
- **Cadastro:** nome, e-mail, senha com confirmação, data de nascimento opcional (máscara DD/MM/AAAA) e áreas de interesse vindas da API.
- **Diário de Emoções:** emojis das emoções (vêm da API, então novas emoções cadastradas no banco aparecem sozinhas), as 3 perguntas (o que te fez bem, o que te fez mal, o que você aprendeu hoje), lista das entradas com rolagem infinita e puxar para atualizar.
- **Relatório:** período de 7, 30 ou 90 dias, total de entradas, humor médio, dias seguidos, distribuição por emoção, gráfico dia a dia e uma mensagem de acolhimento.

## Aceite do Termo (LGPD)

O texto do aviso, do **Termo de Autorização** e da **Política de Privacidade** fica na API (`GET /api/termos/atual`), com número de versão. O app só desenha o que a API envia.

- **Antes do primeiro registro:** depois do login, quem ainda não aceitou a versão vigente vê a tela de **Consentimento** (o que pode ser guardado, para quê, onde ficam os dados, links para o Termo e a Política) e o diário fica bloqueado. A caixa "Li e autorizo…" começa **desmarcada** e "Concordo e continuar" só funciona com ela marcada. "Não concordo" explica que sem autorização não dá para registrar.
- **No cadastro:** o aviso aparece **antes** da escolha das áreas de interesse (que também são dados sensíveis); as áreas só destravam depois de marcar a autorização, e o aceite é gravado junto com a conta.
- **Prova do aceite:** a API guarda data e hora, versão, o texto exibido, IP e aparelho.
- **Nova versão do Termo:** ao subir a versão na API, todos veem a tela de novo no próximo login (ou na próxima gravação).
- **Privacidade (aba):** mostra quando e qual versão foi aceita, abre o Termo e a Política e permite **retirar a autorização**, que apaga a conta e todos os dados (pede a senha).
- Login e Cadastro têm links para o Termo e a Política.

## Temas de cores

Na aba **Privacidade**, o cartão **Aparência** tem o botão **Escolher outro tema de cores**. São 9 temas: **Acolhedor** (o estilo original, padrão), Oceano, Floresta, Lavanda, Rosa, Café, Menta, Grafite (alto contraste) e Noite (escuro). A troca vale na hora, em todas as telas, e fica salva neste aparelho (também vale para a tela de login).

- `src/theme/tema.js`: as paletas (`temas`). Para criar outro tema, copie um bloco e troque o `id`, o `nome` e as cores.
- `src/theme/TemaContext.js`: guarda o tema escolhido; os componentes leem as cores com `const { cores } = useTema()`.
- `src/models/temaStorage.js`: grava a escolha no aparelho.
- Os temas novos foram conferidos para boa leitura (contraste de texto, botões e avisos). O tema padrão foi mantido exatamente como era.
- O PDF do relatório mantém sempre as cores do tema padrão.

## Gerar PDF do relatório

Na aba **Relatório**, escolha 7, 30 ou 90 dias e toque em **Gerar PDF**. O PDF traz o nome, o período, total de entradas, humor médio, dias seguidos, a distribuição por emoção, o gráfico dia a dia e a mensagem de acolhimento (o texto das entradas não vai para o PDF).

| Plataforma | O que acontece |
|---|---|
| Android | gera o arquivo (`relatorio-diario-30-dias-AAAA-MM-DD.pdf`) e abre no leitor de PDF; sem leitor instalado, abre o menu de compartilhar |
| iOS | gera o arquivo e abre a folha de compartilhamento (Visualizar, Arquivos, Livros...) |
| Navegador | abre uma janela de impressão: escolha "Salvar como PDF" (o navegador precisa permitir pop-ups) |

Bibliotecas: `expo-print`, `expo-sharing`, `expo-file-system` e `expo-intent-launcher`.

## O que ainda não está nesta versão

- Tela **Dicas SOS**.
- Editar e excluir entradas pela tela (a API já suporta).
- Envio de foto (a API só guarda o endereço da imagem).
